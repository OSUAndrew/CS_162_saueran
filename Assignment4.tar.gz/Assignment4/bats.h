#ifndef BATS_H
#define BATS_H

#define BATS_PERCEPT "You hear wings flapping."

#include"event.h"
#include"adventurer.h"

class Bat:public Event{
   public:
      Bat();
      ~Bat();//only needed to make sure destructor is defined
      void activate(Adventurer &,int size);
      Bat *clone();
};

#endif

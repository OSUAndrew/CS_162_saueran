/******************************************************************************************************************* 
 * Program:driver.cpp(Hunt the Wumpus)
 * Author:ProgrammersApprentice
 * Date:05/28/2019
 * Description:Explore a dark cave, dodge hazards and the Wumpus, get the gold, and get out alive!
 * Inputs:cave size, debug mode or real mode, then during the game, which way to go, and which way to fire arrows.
 * Outputs:cave map,percepts,events.
 * ****************************************************************************************************************/

#include<iostream>
#include<cstdlib>
#include<string>
#include<ctime>

#include"bats.h"
#include"dungeon.h"
#include"event.h"
#include"review.h"

using namespace std;

/*********************************************************************  
 ** Function: main()
 ** Description: Main function, takes in command line arguments, error handles them, then runs the main game using dungeon functions.
 ** Parameters: argc,argv
 ** Pre-Conditions: None
 ** Post-Conditions: All dynamic memory has been freed.
 *********************************************************************/ 
int main(int argc, char** argv){
   srand(time(NULL));
   if(argc!=3){
      cout << "Not enough arguments(usage: project size debug)" << endl;
      return 0;
   }
   int size=atoi(argv[1]);
   if(size<4){
      cout << "Size too small(must be 4 or over)" << endl;
      return 0;
   }
   bool visible=false;
   char *debug=argv[2];
   if(!strcmp(debug,"true"))
      visible=true;
   else if(!strcmp(debug,"false"))
      visible=false;
   else{
      cout << "Debug parameter invalid(please enter 'true' or 'false')." << endl;
      return 0;
   }
   Dungeon d(size);
   d.fill_rooms();
   d.place_escape_rope();
   d.main_loop(visible);
   return 0; 
}

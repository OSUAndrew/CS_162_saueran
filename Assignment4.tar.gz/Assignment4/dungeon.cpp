#include<iostream>
#include<string>
#include<cstdlib>
#include<vector>

#include"bats.h"
#include"dungeon.h"
#include"gold.h"
#include"pits.h"
#include"room.h"
#include"wumpus.h"

using namespace std;

/*********************************************************************  
 ** Function: Dungeon()
 ** Description: Dungeon constructor(based on size)
 ** Parameters: size
 ** Pre-Conditions: size>=4
 ** Post-Conditions: grid is a sizexsize grid
 *********************************************************************/ 
Dungeon::Dungeon(int size){
   this->size=size;
   for(int i=0;i<size;i++){
      vector<Room> current;
      for(int j=0;j<size;j++){
	 current.push_back(Room(i,j));
      }
      grid.push_back(current);
   }
   erx=rand()%size;
   ery=rand()%size;
   player.set_x_y(erx,ery);
}

/*
Dungeon::~Dungeon(){}

Dungeon::Dungeon(const Dungeon &old_dungeon){
   size=old_dungeon.size;
   grid=old_dungeon.grid;
   erx=old_dungeon.erx;
   ery=old_dungeon.ery;
   player=old_dungeon.player;
}

Dungeon &Dungeon::operator=(const Dungeon &old_dungeon){
   size=old_dungeon.size;
   grid=old_dungeon.grid;
   erx=old_dungeon.erx;
   ery=old_dungeon.ery;
   player=old_dungeon.player;
   return *this;
}
*/

/*********************************************************************  
 ** Function: place_event
 ** Description: places an event somewhere in the dungeon randomly(for start and Wumpus moves)
 ** Parameters: Event *e(for determining what type)
 ** Pre-Conditions: dungeon isn't full
 ** Post-Conditions: event is not on top of another event(though it may be on the escape rope)
 *********************************************************************/ 
void Dungeon::place_event(Event *e){
   bool go=true;
   int tempx;
   int tempy;
   while(go){
      tempx=rand()%size;
      tempy=rand()%size;
      if(!grid[tempx][tempy].get_contents()){
         grid[tempx][tempy].set_contents(e);
	 go=false;
      }
   }
}

/*********************************************************************  
 ** Function: fill_rooms
 ** Description: Puts all events in the dungeon
 ** Parameters: None
 ** Pre-Conditions: No events in the dungeon yet.
 ** Post-Conditions: All events in the dungeon
 *********************************************************************/ 
void Dungeon::fill_rooms(){
   Gold *gol=new Gold;
   this->place_event(gol);
   Wumpus *wump=new Wumpus;
   this->place_event(wump);
   Bat *bat1=new Bat;
   this->place_event(bat1);
   Bat *bat2=new Bat;
   this->place_event(bat2);
   Pit *pit1=new Pit;
   this->place_event(pit1);
   Pit *pit2=new Pit;
   this->place_event(pit2);
}

/*********************************************************************  
 ** Function: place_escape_rope
 ** Description: Places the escape rope and the player in an empty room
 ** Parameters: None
 ** Pre-Conditions: All events have been placed
 ** Post-Conditions: Escape rope has been placed in an empty room(by setting erx and ery) with the player
 *********************************************************************/ 
void Dungeon::place_escape_rope(){
   bool go=true;
   int tempx;
   int tempy;
   while(go){
      tempx=rand()%size;
      tempy=rand()%size;
      if(!grid[tempx][tempy].get_contents()){
         erx=tempx;
	 ery=tempy;
	 go=false;
      }
   }
   player.set_x_y(erx,ery);
}

/*********************************************************************  
 ** Function: display_dungeon
 ** Description: Displays the dungeon, only displaying the events and rope if debug mode is on.
 ** Parameters: debug
 ** Pre-Conditions: Dungeon has been initialized
 ** Post-Conditions: None
 *********************************************************************/ 
void Dungeon::display_dungeon(bool debug) const{
   string percept;
   for(int i=0;i<size;i++){
      for(int j=0;j<size;j++){
         if(grid[i][j].get_contents()&&debug){
	    percept=(*(grid[i][j].get_contents())).get_percept();
	    if(percept==BATS_PERCEPT)
	       cout << " B";
	    else if(percept==GOLD_PERCEPT)
	       cout << " G";
	    else if(percept==PITS_PERCEPT)
	       cout << " P";
	    else if(percept==WUMPUS_PERCEPT)
	       cout << " W";
	 }
	 else if(i==erx&&j==ery&&debug)
	    cout << " R";
	 else if(i==player.get_x()&&j==player.get_y())
	    cout << " @";
	 else
	    cout << " *";
      }
      cout << endl;
   }
}

/*********************************************************************  
 ** Function: move_adventurer
 ** Description: Moves the player in the indicated direction
 ** Parameters: direction(0=N,1=E,2=S,3=W)
 ** Pre-Conditions: Adventurer is in a valid position in the dungeon
 ** Post-Conditions: Adventurer has moved in the given direction(unless they hit a wall)
 *********************************************************************/ 
void Dungeon::move_adventurer(int direction){
   if(direction==0&&player.get_x()>0)
      player.set_x_y(player.get_x()-1,player.get_y());
   else if(direction==1&&player.get_y()<size-1)
      player.set_x_y(player.get_x(),player.get_y()+1);
   else if(direction==2&&player.get_x()<size-1)
      player.set_x_y(player.get_x()+1,player.get_y());
   else if(direction==3&&player.get_y()>0)
      player.set_x_y(player.get_x(),player.get_y()-1);
}

/*********************************************************************  
 ** Function: fire_arrow
 ** Description: Fires arrow in given direction if the player has any left. Kills Wumpus if it's still alive and the shot hits. If the shot misses and the Wumpus is still alive, it 75% chance moves to another random room
 ** Parameters: direction
 ** Pre-Conditions: Only one Wumpus, num_arrows is not negative
 ** Post-Conditions: num_arrows decremented if it was greater than 0
 *********************************************************************/ 
void Dungeon::fire_arrow(int direction){
   if(player.get_num_arrows()==0){
      cout << "You are out of arrows!" << endl;
      return;
   }
   player.remove_arrow();
   for(int i=0;i<size;i++){
      for(int j=0;j<size;j++){
         if(grid[i][j].get_contents()&&(*(grid[i][j].get_contents())).get_percept()==WUMPUS_PERCEPT){
	    (*(grid[i][j].get_contents())).take_arrow(player.get_x(),player.get_y(),direction);
	    if(!(*(grid[i][j].get_contents())).get_dead()&&rand()%4){
	       cout << "The Wumpus wakes up and moves around." << endl;
               place_event(grid[i][j].get_contents()->clone());
               grid[i][j].set_contents(NULL);
	       i=size;
	       j=size;
	    }
	 }
      }
   }
   cout << "You have " << player.get_num_arrows() << " arrows left." << endl;
}

/*********************************************************************  
 ** Function: resolve_events
 ** Description: Activates the event the player is on, then prints percepts for all events next to the player.
 ** Parameters: None
 ** Pre-Conditions: Player is in in-bounds position.
 ** Post-Conditions: None
 *********************************************************************/ 
void Dungeon::resolve_events(){
   int oldx=-1;
   int oldy=-1;
   while(oldx!=player.get_x()||oldy!=player.get_y()){
      oldx=player.get_x();
      oldy=player.get_y();
      if(grid[oldx][oldy].get_contents()){
         (*(grid[oldx][oldy].get_contents())).activate(player,size);
      }
   }
   if(player.get_dead())
      return;
   if(oldx>0&&grid[oldx-1][oldy].get_contents())
      (*(grid[oldx-1][oldy].get_contents())).print_percept();
   if(oldy>0&&grid[oldx][oldy-1].get_contents())
      (*(grid[oldx][oldy-1].get_contents())).print_percept();
   if(oldx<size-1&&grid[oldx+1][oldy].get_contents())
      (*(grid[oldx+1][oldy].get_contents())).print_percept();
   if(oldy<size-1&&grid[oldx][oldy+1].get_contents())
      (*(grid[oldx][oldy+1].get_contents())).print_percept();
}

/*********************************************************************  
 ** Function: take_adventurer_turn
 ** Description: Displays the dungeon, takes in a command, executes the command, resolves events player may be on.
 ** Parameters: debug(for use in display_dungeon)
 ** Pre-Conditions: Dungeon has been initialized
 ** Post-Conditions: None
 *********************************************************************/ 
void Dungeon::take_adventurer_turn(bool debug){
   display_dungeon(debug);
   int direction;
   string command;
   getline(cin,command);
   if(command=="w"||command==" w")
      direction=0;
   else if(command=="d"||command==" d")
      direction=1;
   else if(command=="s"||command==" s")
      direction=2;
   else if(command=="a"||command==" a")
      direction=3;
   else{
      cout << "Invalid command." << endl;
      return;
   }
   if(command[0]!=' ')
      move_adventurer(direction);
   else
      fire_arrow(direction);
   resolve_events();
}

/*********************************************************************  
 ** Function: main_loop
 ** Description: Takes turns until the player dies or gets out with the gold, then displays a victory or defeat message.
 ** Parameters: debug(ultimately for use in display_dungeon)
 ** Pre-Conditions: Dungeon has been initialized
 ** Post-Conditions: Game is over, exit the program.
 *********************************************************************/ 
void Dungeon::main_loop(bool debug){
   resolve_events();
   while(!player.get_dead()&&!(player.get_x()==erx&&player.get_y()==ery&&player.get_has_gold())){
      take_adventurer_turn(debug);
   }
   if(player.get_dead())
      cout << "You died! You lose!" << endl;
   else if(player.get_x()==erx&&player.get_y()==ery&&player.get_has_gold())
      cout << "You escaped with the gold! You win!" << endl;
}

#ifndef ADVENTURER_H
#define ADVENTURER_H

#include<iostream>

using namespace std;

class Adventurer{
   private:
      int x;
      int y;
      int num_arrows;
      bool has_gold;
      bool dead;
   public:
      Adventurer();
      Adventurer(int x,int y);
      
      int get_x() const;
      int get_y() const;
      void set_x_y(int x,int y);
      int get_num_arrows() const;
      void remove_arrow();
      bool get_has_gold();
      bool get_dead();
      void pick_up_gold();
      void kill();
};

#endif

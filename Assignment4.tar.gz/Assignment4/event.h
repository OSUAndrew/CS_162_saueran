#ifndef EVENT_H
#define EVENT_H

#include<string>

#include"adventurer.h"

using namespace std;

class Event{
   private:
      int x;
      int y;
      string percept;
   public:
      virtual ~Event()=0;
      virtual void activate(Adventurer &,int size) = 0;
      
      virtual void take_arrow(int,int,int);
      virtual bool get_dead();
      
      virtual Event *clone() = 0;

      int get_x() const;
      int get_y() const;
      void set_x_y(int x,int y);
      void print_percept() const;
      string get_percept() const;
      void set_percept(string);
};

#endif

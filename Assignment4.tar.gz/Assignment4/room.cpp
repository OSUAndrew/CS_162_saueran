#include<iostream>
#include<string>

#include"room.h"

/*********************************************************************  
 ** Function: Default Room constructor
 ** Description: Initializes Room variables
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: contents initialized to null,x=y=0(must change to reflect reality)
 *********************************************************************/ 
Room::Room(){
   x=0;
   y=0;
   cout << "Default room constructor called!" << endl;
   contents=NULL;
}

/*********************************************************************  
 ** Function: Room constructor with x and y
 ** Description: Constructs a room at x,y
 ** Parameters: int x,int y
 ** Pre-Conditions: Room is actually being constructed at x,y in the dungeon
 ** Post-Conditions: contents initialized to null,x,y have been set.
 *********************************************************************/ 
Room::Room(int x,int y){
   this->x=x;
   this->y=y;
   contents=NULL;
}

/*********************************************************************  
 ** Function: Room destructor
 ** Description: Deletes contents dynamic memory when the object is destroyed
 ** Parameters: 
 ** Pre-Conditions: 
 ** Post-Conditions: 
 *********************************************************************/ 
Room::~Room(){
   if(contents){
      delete contents;
   }
}

/*********************************************************************  
 ** Function: Room()
 ** Description: Room Copy Constructor
 ** Parameters: const Room &r
 ** Pre-Conditions: r has been fully initialized
 ** Post-Conditions: this room is now a duplicate of r
 *********************************************************************/ 
Room::Room(const Room &r){
   x=r.x;
   y=r.y;
   if(r.get_contents()){
      contents=(*(r.get_contents())).clone();
   }
   else
      contents=NULL;
}

/*********************************************************************  
 ** Function: operator=
 ** Description: Room assignment operator overload
 ** Parameters: const Room &r
 ** Pre-Conditions: r has been fully initialized
 ** Post-Conditions: this pre-existing room is now a duplicate of r
 *********************************************************************/ 
Room &Room::operator=(const Room &r){
   x=r.x;
   y=r.y;
   if(contents){
      delete contents;
   }
   if(r.get_contents()){
      contents=(*(r.get_contents())).clone();
   }
   else
      contents=NULL;
   return *this;
}

/*********************************************************************  
 ** Function: get_x
 ** Description: Getter for x
 ** Parameters: None
 ** Pre-Conditions: x is defined
 ** Post-Conditions: Returns x
 *********************************************************************/ 
int Room::get_x() const{
   return x;
}

/*********************************************************************  
 ** Function: get_y
 ** Description: Getter for y
 ** Parameters: None
 ** Pre-Conditions: y is defined
 ** Post-Conditions: Returns y
 *********************************************************************/ 
int Room::get_y() const{
   return y;
}

/*********************************************************************  
 ** Function: set_x_y
 ** Description: Setter for x and y
 ** Parameters: int x,int y
 ** Pre-Conditions: x,y within dungeon range
 ** Post-Conditions: member vars x and y set
 *********************************************************************/ 
void Room::set_x_y(int x,int y){
   this->x=x;
   this->y=y;
}

/*********************************************************************  
 ** Function: get_contents
 ** Description: Getter for contents
 ** Parameters: None
 ** Pre-Conditions: contents is defined
 ** Post-Conditions: Returns contents
 *********************************************************************/ 
Event *Room::get_contents() const{
   return contents;
}

/*********************************************************************  
 ** Function: set_contents
 ** Description: Setter for contents(also makes sure contents has the proper position)
 ** Parameters: Event *contents
 ** Pre-Conditions: None
 ** Post-Conditions: Previous dynamic memory deleted, contents set
 *********************************************************************/ 
void Room::set_contents(Event *contents){
   if(this->contents){
      delete this->contents;
   }
   this->contents=contents;
   if(this->contents){
      this->contents->set_x_y(x,y);
   }
}

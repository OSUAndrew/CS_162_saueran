#include<iostream>
#include<string>
#include"event.h"

using namespace std;

/*********************************************************************  
 ** Function: ~Event
 ** Description: Event destructor(Only needed to avoid undefined behavior)
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: None
 *********************************************************************/ 
Event::~Event(){}

/*********************************************************************  
 ** Function: get_x
 ** Description: Getter for x
 ** Parameters: None
 ** Pre-Conditions: x is defined
 ** Post-Conditions: Returns x
 *********************************************************************/ 
int Event::get_x() const{
   return x;
}

/*********************************************************************  
 ** Function: get_y
 ** Description: Getter for y
 ** Parameters: None
 ** Pre-Conditions: y is defined
 ** Post-Conditions: Returns y
 *********************************************************************/ 
int Event::get_y() const{
   return y;
}

/*********************************************************************  
 ** Function: set_x_y
 ** Description: Setter for x and y
 ** Parameters: int x,int y
 ** Pre-Conditions: x,y within dungeon range
 ** Post-Conditions: member vars x and y set
 *********************************************************************/ 
void Event::set_x_y(int x,int y){
   this->x=x;
   this->y=y;
}

/*********************************************************************  
 ** Function: print_percept
 ** Description: prints the percept to screen
 ** Parameters: None
 ** Pre-Conditions: percept is defined
 ** Post-Conditions: percept has been printed
 *********************************************************************/ 
void Event::print_percept() const{
   cout << percept << endl;
}

/*********************************************************************  
 ** Function: get_percept
 ** Description: Getter for percept
 ** Parameters: None
 ** Pre-Conditions: percept is defined
 ** Post-Conditions: Returns percept
 *********************************************************************/  
string Event::get_percept() const{
   return percept;
}

/*********************************************************************  
 ** Function: set_percept
 ** Description: Setter for percept
 ** Parameters: string percept
 ** Pre-Conditions: percept is indicative of the object
 ** Post-Conditions: percept has been set
 *********************************************************************/ 
void Event::set_percept(string percept){
   this->percept=percept;
}


/*********************************************************************  
 ** Function: take_arrow and get_dead
 ** Description: Wumpus functions defined in event to they can be called from an event pointer
 ** Parameters: As they are in the actual inherited functions
 ** Pre-Conditions: None
 ** Post-Conditions: None
 *********************************************************************/ 
void Event::take_arrow(int a,int b,int c){}
bool Event::get_dead(){return false;}

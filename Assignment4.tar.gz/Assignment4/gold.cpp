#include<iostream>
#include<string>

#include"gold.h"
#include"adventurer.h"

using namespace std;

/*********************************************************************  
 ** Function: Gold
 ** Description: Default Gold constructor
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: x,y set to 0,percept set to GOLD_PERCEPT
 *********************************************************************/ 
Gold::Gold(){
   this->set_x_y(0,0);
   this->set_percept(GOLD_PERCEPT);
}

/*********************************************************************  
 ** Function: ~Gold
 ** Description: Gold destructor(Only needed to avoid undefined behavior)
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: None
 *********************************************************************/ 
Gold::~Gold(){}

/*********************************************************************  
 ** Function: activate
 ** Description: Activates the gold, causing the player to pick it up
 ** Parameters: Adventurer &player,int size
 ** Pre-Conditions: player stepped on this gold
 ** Post-Conditions: player has picked up the gold
 *********************************************************************/ 
void Gold::activate(Adventurer &player,int size){
   if(!player.get_has_gold()){
      cout << "You found the treasure! You pick it up." << endl;
      player.pick_up_gold();
   }
   else
      cout << "Your pockets are full, you can't take any more gold." << endl;
}

/*********************************************************************  
 ** Function: clone
 ** Description: Creates a pointer to a copy of this object
 ** Parameters: None
 ** Pre-Conditions: values initialized
 ** Post-Conditions: returns pointer to identical object
 *********************************************************************/ 
Gold *Gold::clone(){
   Gold *result=new Gold;
   result->set_x_y(this->get_x(),this->get_y());
   result->set_percept(this->get_percept());
   return result;
}

#ifndef PITS_H
#define PITS_H

#define PITS_PERCEPT "You feel a breeze."

#include"event.h"

class Pit:public Event{
   public:
      Pit();
      ~Pit();
      void activate(Adventurer &,int size);
      Pit *clone();
};

#endif

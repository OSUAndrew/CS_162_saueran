#ifndef DUNGEON_H
#define DUNGEON_H

#include<vector>
#include"room.h"
#include"adventurer.h"

class Dungeon{
   private:
      int size;
      vector<vector<Room>> grid;
      int erx;//escape rope x
      int ery;//escape rope y
      Adventurer player;
   public:
      Dungeon(int size);
      /*
      ~Dungeon();
      Dungeon(const Dungeon &);
      Dungeon &operator=(const Dungeon &);
      */
      void place_event(Event *e);
      void fill_rooms();
      void place_escape_rope();
      void display_dungeon(bool debug) const;
      
      void move_adventurer(int direction);
      void fire_arrow(int direction);
      void resolve_events();
      void take_adventurer_turn(bool debug);
      void main_loop(bool debug);
};

#endif

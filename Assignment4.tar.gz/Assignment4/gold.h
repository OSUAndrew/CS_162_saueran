#ifndef GOLD_H
#define GOLD_H

#define GOLD_PERCEPT "You see a glimmer nearby."

#include"event.h"

class Gold:public Event{
   public:
      Gold();
      ~Gold();
      void activate(Adventurer &,int size);
      Gold *clone();
};

#endif

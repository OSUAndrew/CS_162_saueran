#include<iostream>
#include<string>

#include"bats.h"
#include"adventurer.h"

using namespace std;

/*********************************************************************  
 ** Function: Bat
 ** Description: Default Bat constructor
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: x,y set to 0,percept set to BATS_PERCEPT
 *********************************************************************/ 
Bat::Bat(){
   this->set_x_y(0,0);
   this->set_percept(BATS_PERCEPT);
}

/*********************************************************************  
 ** Function: ~Bat
 ** Description: Bat destructor(Only needed to avoid undefined behavior)
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: None
 *********************************************************************/ 
Bat::~Bat(){}

/*********************************************************************  
 ** Function: activate
 ** Description: Activates the super bat, flying the player to a random position
 ** Parameters: Adventurer &player,int size
 ** Pre-Conditions: player stepped on this bat
 ** Post-Conditions: player has been moved to a new random spot
 *********************************************************************/ 
void Bat::activate(Adventurer &player,int size){
   cout << "A Super Bat picks you up and flies you around the dungeon!" << endl;
   int a=rand()%size;//destination x
   int b=rand()%size;//destination y
   player.set_x_y(a,b);
}

/*********************************************************************  
 ** Function: clone
 ** Description: Creates a pointer to a copy of this object
 ** Parameters: None
 ** Pre-Conditions: values initialized
 ** Post-Conditions: returns pointer to identical object
 *********************************************************************/ 
Bat *Bat::clone(){
   Bat *result=new Bat;
   result->set_x_y(this->get_x(),this->get_y());
   result->set_percept(this->get_percept());
   return result;
}

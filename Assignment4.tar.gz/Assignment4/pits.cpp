#include<iostream>
#include<string>

#include"pits.h"
#include"adventurer.h"

using namespace std;

/*********************************************************************  
 ** Function: Pit
 ** Description: Default Pit constructor
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: x,y set to 0,percept set to PITS_PERCEPT
 *********************************************************************/ 
Pit::Pit(){
   this->set_x_y(0,0);
   this->set_percept(PITS_PERCEPT);
}

/*********************************************************************  
 ** Function: ~Pit
 ** Description: Pit destructor(Only needed to avoid undefined behavior)
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: None
 *********************************************************************/ 
Pit::~Pit(){}

/*********************************************************************  
 ** Function: activate
 ** Description: Activates the pit, killing the player
 ** Parameters: Adventurer &player,int size
 ** Pre-Conditions: player stepped on this pit
 ** Post-Conditions: player has been killed
 *********************************************************************/ 
void Pit::activate(Adventurer &player,int size){
   cout << "You fall into a pit and die lol!" << endl;
   player.kill();
}

/*********************************************************************  
 ** Function: clone
 ** Description: Creates a pointer to a copy of this object
 ** Parameters: None
 ** Pre-Conditions: values initialized
 ** Post-Conditions: returns pointer to identical object
 *********************************************************************/ 
Pit *Pit::clone(){
   Pit *result=new Pit;
   result->set_x_y(this->get_x(),this->get_y());
   result->set_percept(this->get_percept());
   return result;
}

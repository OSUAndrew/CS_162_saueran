#ifndef WUMPUS_H
#define WUMPUS_H

#define WUMPUS_PERCEPT "You smell a terrible stench."

#include"event.h"

class Wumpus:public Event{
   private:
      bool dead;
   public:
      Wumpus();
      ~Wumpus();
      void activate(Adventurer &,int size);
      void take_arrow(int,int,int);
      Wumpus *clone();

      bool get_dead();
};

#endif

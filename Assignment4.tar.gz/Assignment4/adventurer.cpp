#include<iostream>
#include<string>
#include<cstdlib>

#include"adventurer.h"

using namespace std;

/*********************************************************************  
 ** Function: Adventurer
 ** Description: Default adventurer constructor
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: x=y=0(need to move to proper position), adventurer has 3 arrows, no gold, and isn't dead
 *********************************************************************/ 
Adventurer::Adventurer(){
//   cout << "Default adventurer constructor called!" << endl;
   x=0;
   y=0;
   num_arrows=3;
   has_gold=false;
   dead=false;
}

/*********************************************************************  
 ** Function: Adventurer
 ** Description: Positioned adventurer constructor
 ** Parameters: int x,int y(signifying adventurer's position)
 ** Pre-Conditions: x and y in cave range
 ** Post-Conditions: x and y set, 3 arrows, no gold, isn't dead
 *********************************************************************/ 
Adventurer::Adventurer(int x,int y){
   this->x=x;
   this->y=y;
   num_arrows=3;
   has_gold=false;
   dead=false;
}

/*********************************************************************  
 ** Function: get_x
 ** Description: Getter for x
 ** Parameters: None
 ** Pre-Conditions: x is defined
 ** Post-Conditions: Returns x
 *********************************************************************/ 
int Adventurer::get_x() const{
   return x;
}

/*********************************************************************  
 ** Function: get_y
 ** Description: Getter for y
 ** Parameters: None
 ** Pre-Conditions: y is defined
 ** Post-Conditions: Returns y
 *********************************************************************/ 
int Adventurer::get_y() const{
   return y;
}

/*********************************************************************  
 ** Function: set_x_y
 ** Description: setter for x and y
 ** Parameters: int x,int y
 ** Pre-Conditions: x and y in dungeon range
 ** Post-Conditions: x and y have been set
 *********************************************************************/ 
void Adventurer::set_x_y(int x,int y){
   this->x=x;
   this->y=y;
}

/*********************************************************************  
 ** Function: get_num_arrows
 ** Description: getter for num_arrows
 ** Parameters: none
 ** Pre-Conditions: num_arrows initialized and positive
 ** Post-Conditions: returns num_arrows
 *********************************************************************/ 
int Adventurer::get_num_arrows() const{
   return num_arrows;
}

/*********************************************************************  
 ** Function: remove_arrow
 ** Description: removes an arrow after the player shot it.
 ** Parameters: none
 ** Pre-Conditions: num_arrows>0
 ** Post-Conditions: arrow removed from num_arrows
 *********************************************************************/ 
void Adventurer::remove_arrow(){
   num_arrows-=1;
}

/*********************************************************************  
 ** Function: get_has_gold
 ** Description: getter for has_gold
 ** Parameters: none
 ** Pre-Conditions: has_gold is initialized
 ** Post-Conditions: returns has_gold
 *********************************************************************/ 
bool Adventurer::get_has_gold(){
   return has_gold;
}

/*********************************************************************  
 ** Function: get_dead
 ** Description: getter for dead
 ** Parameters: none
 ** Pre-Conditions: dead is initialized
 ** Post-Conditions: returns dead
 *********************************************************************/ 
bool Adventurer::get_dead(){
   return dead;
}

/*********************************************************************  
 ** Function: pick_up_gold
 ** Description: sets has_gold to true(after player encountered gold)
 ** Parameters: none
 ** Pre-Conditions: gold was activated
 ** Post-Conditions: has_gold is true
 *********************************************************************/ 
void Adventurer::pick_up_gold(){
   has_gold=true;
}

/*********************************************************************  
 ** Function: kill
 ** Description: kills adventurer
 ** Parameters: none
 ** Pre-Conditions: dead is false
 ** Post-Conditions: dead is true
 *********************************************************************/ 
void Adventurer::kill(){
   dead=true;
}

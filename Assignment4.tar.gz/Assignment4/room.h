#ifndef ROOM_H
#define ROOM_H

#include"event.h"

class Room{
   private:
      int x;
      int y;
      Event *contents;
   public:
      Room();
      Room(int x,int y);//should use this
      ~Room();
      Room(const Room &);
      Room &operator=(const Room &);

      int get_x() const;
      int get_y() const;
      void set_x_y(int x,int y);
      Event *get_contents() const;
      void set_contents(Event *);
};

#endif

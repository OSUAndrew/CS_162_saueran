#include<iostream>
#include<string>

#include"wumpus.h"
#include"adventurer.h"

using namespace std;

/*********************************************************************  
 ** Function: Wumpus
 ** Description: Default Wumpus constructor
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: x,y set to 0,percept set to WUMPUS_PERCEPT
 *********************************************************************/ 
Wumpus::Wumpus(){
   this->set_x_y(0,0);
   this->set_percept(WUMPUS_PERCEPT);
   dead=false;
}

/*********************************************************************  
 ** Function: ~Wumpus
 ** Description: Wumpus destructor(Only needed to avoid undefined behavior)
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: None
 *********************************************************************/ 
Wumpus::~Wumpus(){}

/*********************************************************************  
 ** Function: activate
 ** Description: Activates the Wumpus, killing the player if it is still alive
 ** Parameters: Adventurer &player,int size
 ** Pre-Conditions: player stepped on the Wumpus
 ** Post-Conditions: player or Wumpus is dead
 *********************************************************************/ 
void Wumpus::activate(Adventurer &player,int size){
   if(!dead){
      cout << "The Wumpus eats you alive. You die in a few hours." << endl;
      player.kill();
   }
   else
      cout << "The Wumpus is dead. Good riddance." << endl;
}

/*********************************************************************  
 ** Function: take_arrow
 ** Description: Determine whether the arrow hits the Wumpus and kill it if it does
 ** Parameters: sourcx,sourcy,direction(coordinates and direction of arrow shot)
 ** Pre-Conditions: arrow has been fired from sourcx,sourcy in direction(0=N,1=E,2=S,3=W)
 ** Post-Conditions: Wumpus is alive or dead depending on whether it hit or missed
 *********************************************************************/ 
void Wumpus::take_arrow(int sourcx,int sourcy,int direction){
   if(dead){
      cout << "The Wumpus is already dead, silly!" << endl;
      return;
   }
   cout << "You shoot an arrow..." << endl;
   if(direction==0)
      dead=(sourcy==this->get_y()&&sourcx>this->get_x()&&sourcx-this->get_x()<=3);
   else if(direction==1)
      dead=(sourcx==this->get_x()&&sourcy<this->get_y()&&this->get_y()-sourcy<=3);
   else if(direction==2)
      dead=(sourcy==this->get_y()&&sourcx<this->get_x()&&this->get_x()-sourcx<=3);
   else if(direction==3)
      dead=(sourcx==this->get_x()&&sourcy>this->get_y()&&sourcy-this->get_y()<=3);
   if(dead)
      cout << "You killed the Wumpus! It screams as the arrow pierces its heart!" << endl;
   else
      cout << "You missed. Nice job, bigshot." << endl;
}

/*********************************************************************  
 ** Function: clone
 ** Description: Creates a pointer to a copy of this object
 ** Parameters: None
 ** Pre-Conditions: values initialized
 ** Post-Conditions: returns pointer to identical object
 *********************************************************************/ 
Wumpus *Wumpus::clone(){
   Wumpus *result=new Wumpus;
   result->set_x_y(this->get_x(),this->get_y());
   result->set_percept(this->get_percept());
   result->dead=dead;
   return result;
}

/*********************************************************************  
 ** Function: get_dead
 ** Description: getter for dead(determine if wumpus is dead)
 ** Parameters: None
 ** Pre-Conditions: dead is initialized
 ** Post-Conditions: dead has been returned
 *********************************************************************/ 
bool Wumpus::get_dead(){
   return dead;
}

//Name:ProgrammersApprentice/AndrewSauer
//main function. Basically, it just reads off the command line arguments and does error handling on argc, then runs the login and spellbook stages of the program in succession.

#include<iostream>
#include<string>
#include"wizardlogin.hpp"
#include"spellbooksort.hpp"

using namespace std;

int main(int argc,char **argv){
   if(argc==3){
      char *wizfile=argv[1];
      char *bookfile=argv[2];
      int access=wizard_login(wizfile);//access=0 if access is denied, otherwise it represents school position.
      if(access){
         main_spellbook_function(bookfile,access);
      }
   }
   else cout << "Invalid arguments." << endl;
   return 0;
}



#include<iostream>
#include<fstream>
#include<string>
#include"wizardlogin.hpp"
#include"review.hpp"

using namespace std;

wizard * create_wizards(int num_wiz){
   wizard *result=new wizard[num_wiz];
   return result;
}

void get_wizard_data(wizard *wizarr, int num_wiz, ifstream &f){
   for(int i=0;i<num_wiz;i++){
      f >> wizarr[i].name;
      f >> wizarr[i].id;
      f >> wizarr[i].password;
      f >> wizarr[i].position_title;
      f >> wizarr[i].beard_length;
   }
}

wizard * get_matching_wizard(wizard *wizarr, int num_wiz, int id, string password){
   for(int i=0;i<num_wiz;i++){
      if(wizarr[i].id==id&&wizarr[i].password==password){
         return wizarr+i;
      }
   }
   return NULL;
}

//returns 0 if access failed, 1 for student access, 2 for teacher access, 3 for headmaster access.
int wizard_login(char *filename){
   ifstream f;
   int num_wiz, id;
   string password;
   wizard *match;

   f.open(filename);
   if(!f.is_open()){
      cout << "File could not be opened." << endl;
      return 0;
   }
   f >> num_wiz;
   wizard *wizarr=create_wizards(num_wiz);
   get_wizard_data(wizarr,num_wiz,f);
   f.close();
   for(int i=0;i<3;i++){
      id=get_positive_int("What is your ID?","That's not an integer.");
      cout << "What is your password?" << endl;
      getline(cin,password);
      match=get_matching_wizard(wizarr,num_wiz,id,password);
      if(match!=NULL){
	 int result;
         cout << "Access granted." << endl;
	 cout << "Name: " << match->name << endl;
	 cout << "ID#: " << match->id << endl;
	 cout << "Position: " << match->position_title << endl;
	 cout << "Beard Length: " << match->beard_length << endl;
	 if(!(match->position_title.compare("Student"))) result=1;
	 else if(!(match->position_title.compare("Teacher"))) result=2;
	 else if(!(match->position_title.compare("Headmaster"))) result=3;
	 else cout << "Error: School position invalid!" << endl;
	 delete_wizard_data(&wizarr,num_wiz);
	 return result;
      }
      else cout << "Access denied." << endl;
   }
   cout << "Three failures, exiting." << endl;
   delete_wizard_data(&wizarr,num_wiz);
   return 0;
}

void delete_wizard_data(wizard **wizarr, int num_wiz){
   delete [] *wizarr;
   wizarr=NULL;
}

/* We need to go through the program and check to see if filestreams are actually opening! */

#include<iostream>
#include<fstream>
#include<string>
#include"review.hpp"
#include"wizardlogin.hpp"
#include"spellbooksort.hpp"

using namespace std;

spellbook * create_spellbooks(int num_books){
   spellbook *result=new spellbook[num_books];
   return result;
}

void get_spellbook_data(spellbook *books, int num_books, ifstream &f){
   for(int i=0;i<num_books;i++){
      f >> books[i].title;
      f >> books[i].author;
      f >> books[i].num_pages;
      f >> books[i].edition;
      f >> books[i].num_spells;
      books[i].s=create_spells(books[i].num_spells);
      books[i].avg_success_rate=get_spell_data(books[i].s,books[i].num_spells,f);
   }
}

spell * create_spells(int num_spells){
   spell *result=new spell[num_spells];
   return result;
}

//returns the average spell success rate
float get_spell_data(spell *spells, int num_spells, ifstream &f){
   float total_success_rate=0;
   for(int i=0;i<num_spells;i++){
      f >> spells[i].name;
      f >> spells[i].success_rate;
      f >> spells[i].effect;
      total_success_rate+=spells[i].success_rate;
   }
   return total_success_rate/(float)(num_spells);
}

spell * all_spells(spellbook *books, int num_books){
   int total_spells=0;
   int offset=0;
   for(int i=0;i<num_books;i++){
      total_spells+=books[i].num_spells;
   }
   spell *result=new spell[total_spells];
   for(int i=0;i<num_books;i++){
      for(int j=0;j<books[i].num_spells;j++){
         result[offset+j]=books[i].s[j];
      }
      offset+=books[i].num_spells;
   }
   return result;
}

void sort_by_length(spellbook *books, int num_books){
   spellbook tmp;
   for(int i=1;i<num_books;i++){
      for(int j=0;j<num_books-i;j++){
         if(books[j].num_pages>books[j+1].num_pages){
	    tmp=books[j];
	    books[j]=books[j+1];
	    books[j+1]=tmp;
	 }
      }
   }
}

int effect_number(spell my_spell){
   if(my_spell.effect=="bubble"){
      return 0;
   }
   else if(my_spell.effect=="memory_loss"){
      return 1;
   }
   else if(my_spell.effect=="fire"){
      return 2;
   }
   else if(my_spell.effect=="poison"){
      return 3;
   }
   else if(my_spell.effect=="death"){
      return 4;
   }
}

//returns the new num_spells, as the spell list may have been shortened due to insufficient access level.
int sort_by_effect(spell *spells, int num_spells, int access_level){
   spell tmp;
   for(int i=1;i<num_spells;i++){
      for(int j=0;j<num_spells-1;j++){
         if(effect_number(spells[j])>effect_number(spells[j+1])){
	    tmp=spells[j];
	    spells[j]=spells[j+1];
	    spells[j+1]=tmp;
	 }
      }
   }
   int result=num_spells;
   if(access_level==1){
      for(int i=0;i<num_spells;i++){
         if(effect_number(spells[i])>=3){
	    result-=1;
	 }
      }
   }
   return result;
}

int block_books(spellbook *books, int num_books){
   int result=num_books;
   int bad_book=0;
   for(int i=0;i<result;i++){
      bad_book=0;
      for(int j=0;j<books[i].num_spells;j++){
         if(books[i].s[j].effect=="poison"||books[i].s[j].effect=="death"){
	    bad_book=1;
	    break;
	 }
      }
      if(bad_book){
	 delete [] books[i].s;//we're about to delete the pointer, we need this, here's what the real problem was.
         for(int j=i;j<result-1;j++){
	    books[j]=books[j+1];
	 }
	 result--;
	 i--;
      }
   }
   for(int i=result;i<num_books;i++){
      books[i].s=NULL;//prevents duplicate pointers.
   }
   return result;
}

void sort_by_success_rate(spellbook *books, int num_books){
   spellbook tmp;
   for(int i=1;i<num_books;i++){
      for(int j=0;j<num_books-i;j++){
         if(books[j].avg_success_rate<books[j+1].avg_success_rate){
	    tmp=books[j];
	    books[j]=books[j+1];
	    books[j+1]=tmp;
	 }
      }
   }
}

void output_books_to_file(spellbook * books, int num_books, string data_type, ofstream &f){
   for(int i=0;i<num_books;i++){
      f << books[i].title << " ";
      if(data_type=="num_pages"){
         f << books[i].num_pages << endl;
      }
      else if(data_type=="avg_success_rate"){
         f << books[i].avg_success_rate << endl;
      }
   }
}

void output_spells_to_file(spell * spells, int num_spells, ofstream &f){
   for(int i=0;i<num_spells;i++){
      f << spells[i].name << " " << spells[i].effect << endl;
   }
}

void spellbook_cycle(int access_level, spellbook *books, int num_books){
   int option=0;
   int output=0;
   ofstream f;
   char *filename=new char[20];
   spell *spells=all_spells(books,num_books);
   int totalspells=0;
   for(int i=0;i<num_books;i++){
      totalspells+=books[i].num_spells;
   }
   if(access_level==1){
      num_books=block_books(books,num_books);
   }
   while(option!=4){
      cout << "Please select an option: " << endl;
      cout << "(1) Sort spellbooks by number of pages." << endl;
      cout << "(2) Sort spells by effect." << endl;
      cout << "(3) Sort spellbooks by average effectiveness." << endl;
      cout << "(4) Exit program." << endl;
      option=0;
      while(!(option<=4&&option>=1)){
         option=get_positive_int("","That's not an option.");
         if(!(option<=4&&option>=1)) cout << "That's not an option." << endl;
      }
      output=0;
      while(!(output==1||output==2)&&option!=4){
         output=get_positive_int("Do you want to output to screen(1) or file(2)?","That's not an option.");
	 if(!(output==1||output==2)) cout << "That's not an option." << endl;
      }
      if(output==2){
	 cout << "Please enter a file to output to." << endl;
	 cin.getline(filename,20);
         f.open(filename);
      }
      if(option==1){
         sort_by_length(books,num_books);
	 if(output==1){
	    for(int i=0;i<num_books;i++){
	       cout << books[i].title << " " << books[i].num_pages << endl;
	    }
	 }
	 else output_books_to_file(books,num_books,"num_pages",f);
      }
      else if(option==2){
         totalspells=sort_by_effect(spells,totalspells,access_level);
	 if(output==1){
	    for(int i=0;i<totalspells;i++){
	       cout << spells[i].name << " " << spells[i].effect << endl;
	    }
	 }
	 else output_spells_to_file(spells,totalspells,f);
      }
      else if(option==3){
         sort_by_success_rate(books,num_books);
	 if(output==1){
	    for(int i=0;i<num_books;i++){
	       cout << books[i].title << " " << books[i].avg_success_rate << endl;
	    }
	 }
	 else output_books_to_file(books,num_books,"avg_success_rate",f);
      }
      else{
	 cout << "Exiting program." << endl;
	 delete [] spells;
      }
      f.close();
   }
   delete [] filename;
}

void delete_info(spellbook ** books, int num_books){
   if(books!=NULL){
      for(int i=0;i<num_books;i++){
	 if((*books)[i].s!=NULL){
	    delete [] (*books)[i].s;
	 }
      }
      delete [] *books;
      books=NULL;
   }
}

void main_spellbook_function(char *filename, int access_level){
   ifstream f;
   int num_books;
   f.open(filename);
   if(!f.is_open()){
      cout << "Spellbook file could not be found." << endl;
      return;
   }
   f >> num_books;
   spellbook *books=create_spellbooks(num_books);
   get_spellbook_data(books,num_books,f);
   f.close();
   spellbook_cycle(access_level,books,num_books);
   delete_info(&books,num_books);
}

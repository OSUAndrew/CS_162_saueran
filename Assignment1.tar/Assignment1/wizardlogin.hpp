//Name:ProgrammersApprentice/AndrewSauer
//this is the file for the login cycle, used to confirm or deny access permission and privilage level.

#ifndef WIZARDLOGIN_H
#define WIZARDLOGIN_H

#include<iostream>
#include<string>
#include<fstream>

using namespace std;

//wizard struct as required by assignment specification
struct wizard{
   string name;
   int id;
   string password;
   string position_title;
   float beard_length;
};

//takes in an integer number of wizards, creates a dynamic array of wizards of that length.
wizard * create_wizards(int);

//Takes in an array of wizards, its length, and a filestream.
//Fills the array with the wizard info it recieves from the filestream.
void get_wizard_data(wizard *, int, ifstream &);

//From wizard array, length, ID, and password, return a pointer to the wizard that matches. If no wizard matches, return NULL instead.
wizard * get_matching_wizard(wizard *, int, int, string);

//Takes in a filename.
//If it can open the file, it repeatedly asks for username and password, until get_matching_wizard returns a pointer.
//Then it outputs the data on the wizard pointed to, deletes dynamic arrays, and returns the access privilage that wizard gets.
int wizard_login(char *);

//deletes the wizard storage array, as it's no longer needed in the spellbook cycle.
void delete_wizard_data(wizard**, int);

#endif

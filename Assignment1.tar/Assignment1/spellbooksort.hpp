//Name:ProgrammersApprentice/AndrewSauer
//This is the file for the spellbook sorting cycle, for after the user is logged in.

#ifndef SPELLBOOKSORT_H
#define SPELLBOOKSORT_H

#include<iostream>
#include<fstream>
#include<string>
#include"wizardlogin.hpp"

using namespace std;

struct spellbook{
   string title;
   string author;
   int num_pages;
   int edition;
   int num_spells;
   float avg_success_rate;
   struct spell *s;
};

struct spell{
   string name;
   float success_rate;
   string effect;
};

//Takes in the integer number of spellbooks, and creates an array of spellbooks of that size.
spellbook * create_spellbooks(int);

//Takes in an array of spellbooks, its length, and a filestream.
//Reads the filestream into the array of spellbooks.
void get_spellbook_data(spellbook *, int, ifstream &);

//Creates an array of spells of length int.
spell * create_spells(int);

//Takes in an array of spells, its length, and a filestream.
//Reads the filestream data into the array of spells.
//Computes and returns the average success rate, so that it can be entered into the parent spellbook struct along with the array of spells.
float get_spell_data(spell *, int, ifstream &);

//Takes in an array of spellbooks and its length.
//Returns an array containing all spells contained in the spellbooks.
spell * all_spells(spellbook *, int);

//Sorts an array of spellbooks of length int from lowest to highest number of pages.
void sort_by_length(spellbook *, int);

//returns an integer encoding the effect of a spell, to be used for access privilages and grouping.
int effect_number(spell);

//Takes in a list of spells, its length, and access permissions.
//Groups spells by effect, effectively sorting them by effect number from lowest to highest.
//The highest effect numbers are the forbidden ones, so the function returns a new array_length which excludes the forbidden spells.
int sort_by_effect(spell *, int, int);

//for use with student access privilages, deletes forbidden books from the list of spellbooks.
//non-forbidden spells in those books are safe, they were already stored in a seperate array by all_spells.
//Returns the new array length.
int block_books(spellbook *, int);

//much like sort_by_length, this sorts the spellbooks by success rate, but from highest to lowest this time.
void sort_by_success_rate(spellbook *, int);

//Inputs a list of spellbooks, its length, a string indicating which data should be displayed, and an output filestream.
//This function can either output a list with success rates or with lengths.
void output_books_to_file(spellbook *, int, string, ofstream &);

//Outputs a list of spells to a file, along with their effects.
void output_spells_to_file(spell *, int, ofstream &);

//The main loop. Invokes most of the above functions, asks what option user wants until they want to quit, asks whether to output to screen or to file, and performes spellbook and spell sorting and output using the above functions.
void spellbook_cycle(int, spellbook*, int);

//deletes spellbook info, wizard info is deleted in its own function, the master spell array is deleted during spellbook_cycle.
void delete_info(spellbook **, int);

//Inputs a filename and access level.
//Opens the file, creates an array of spellbooks based on it, passes that and the access level to spellbook_cycle.
void main_spellbook_function(char *, int);

#endif

//Name:ProgrammersApprentice/AndrewSauer
/* This file is for general use, so that I don't have to rewrite these function in every single assignment. */

#ifndef REVIEW_H
#define REVIEW_H

#include<iostream>
#include<cstdlib>
#include<cstring>

using namespace std;

//takes a c-style string and determines whether it represents a positive int or not.
int is_positive_int(char *);

//Gets a positive int from the user by repeatedly asking them for input until they provide a proper positive int. 
//The first input string is the prompt the function uses to ask for input. 
//The second is the nag it uses to indicate that the user has failed to input a positive int.
int get_positive_int(string, string);

#endif

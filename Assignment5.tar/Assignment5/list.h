#ifndef LINKED_LIST_H
#define LINKED_LIST_H
#include<iostream>
#include<string>
#include<cstdlib>
#include"node.h"

using namespace std;

template<typename T>
class Linked_List{
   private://for some reason makeing template functions private breaks it
      unsigned int length;
      Linked_List_Node<T> *first;
      void splice(Linked_List_Node<T> **,Linked_List_Node<T> **);
      void front(Linked_List *,Linked_List_Node<T> **,Linked_List_Node<T> **);
      Linked_List<T> *merge_ascending(Linked_List *,Linked_List *);
      Linked_List<T> *sort_ascending_r(Linked_List *,bool);

   public:
      Linked_List();
      ~Linked_List();
      Linked_List(const Linked_List &);
      Linked_List<T> &operator=(const Linked_List &);

      unsigned int get_length() const;
      void print() const;
      void clear();
      unsigned int push_front(T);//returns length
      unsigned int push_back(T);
      unsigned int insert(T val,unsigned int index);

      void sort_ascending();
      void sort_descending();
      
      unsigned int get_num_primes();
};

#endif

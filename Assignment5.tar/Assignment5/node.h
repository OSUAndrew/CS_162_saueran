#ifndef NODE_H
#define NODE_H
template<typename T>
class Linked_List_Node{
   public:
      T data;
      Linked_List_Node *next;
};

#endif

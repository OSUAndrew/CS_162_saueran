#include<iostream>
#include<cstdlib>
#include"node.h"
#include"list.h"
#include"review.h"

using namespace std;

/*********************************************************************  
 ** Function: splice
 ** Description: Inserts currentb between currenta and the next node after it.
 ** Parameters: currenta,currentb(double pointers so the pointers can change and not go out of scope)
 ** Pre-Conditions: (*currenta)->data<=currentb, (*currenta)->next->data>currentb or (*currenta)->next is null
 ** Post-Conditions: *currentb is between *currenta and the next node.
 *********************************************************************/ 
template<typename T>
void Linked_List<T>::splice(Linked_List_Node<T> **currenta,Linked_List_Node<T> **currentb){
   Linked_List_Node<T> *tempa=(*currenta)->next;
   (*currenta)->next=*currentb;
   Linked_List_Node<T> *tempb=(*currentb)->next;
   (*currentb)->next=tempa;
   *currentb=tempb;
}

/*********************************************************************  
 ** Function: front
 ** Description: inserts currentb at the front(in retrospect redundant with push_front.)
 ** Parameters: currenta,currentb(double pointers so the pointers can change and not go out of scope)
 ** Pre-Conditions: (*currenta)->data>(*currentb)->data
 ** Post-Conditions: currentb has been inserted at the front, and currenta is now at the front.
 *********************************************************************/ 
template<typename T>
void Linked_List<T>::front(Linked_List *a,Linked_List_Node<T> **currenta,Linked_List_Node<T> **currentb){
   Linked_List_Node<T> *tempb=(*currentb)->next;
   a->first=*currentb;
   (*currentb)->next=*currenta;
   *currenta=*currentb;
   *currentb=tempb;
}

/*********************************************************************  
 ** Function: merge_ascending
 ** Description: merges two linked lists in ascending order
 ** Parameters: a,b(pointers so that the lists can change and not go out of scope)
 ** Pre-Conditions: both input lists are sorted in ascending order, and both are nonempty.
 ** Post-Conditions: The lists have been combined in ascending order, into the list a, and the lengths have been added together.
 *********************************************************************/ 
template<typename T>
Linked_List<T> *Linked_List<T>::merge_ascending(Linked_List *a,Linked_List *b){//for stability, a should be to the left of b
   Linked_List_Node<T> *currenta=a->first;
   Linked_List_Node<T> *currentb=b->first;
   while(currentb){
      if(currenta){
	 if(currenta->next){
	    if(currenta->data<=currentb->data){
	       if(currenta->next->data>currentb->data){
                  splice(&currenta,&currentb);
	       }
	       else
		  currenta=currenta->next;
	    }
	    else{
               front(a,&currenta,&currentb);
	    }
	 }
         else{
	    if(currenta->data<=currentb->data){
	       currenta->next=currentb;
	       break;
	    }
	    else{
	       a->first=currentb;
	       currentb->next=currenta;
	       break;
	    }
	 }
      }
      else cout << "Error! currenta null in merge!" << endl;
   }
   a->length+=b->length;
   return a;
}

/*********************************************************************  
 ** Function: sort_ascending_r
 ** Description: Recursive section of Merge sort
 ** Parameters: sortee,last(last exists to make sure the top level doesn't try to delete the object it's being called from)
 ** Pre-Conditions: last reflects whether the function is top-level
 ** Post-Conditions: list has been sorted, has proper length, only one list is left allocated unless last is true.
 *********************************************************************/ 
template<typename T>
Linked_List<T> *Linked_List<T>::sort_ascending_r(Linked_List *sortee,bool last){//implement with Merge Sort
   if(sortee->length<=1){
      return sortee;
   }
   Linked_List<T> *a=new Linked_List;
   Linked_List<T> *b=new Linked_List;
   a->length=1;
   while(a->length*2<sortee->length){
      a->length*=2;
   }
   b->length=sortee->length-a->length;
   a->first=sortee->first;
   Linked_List_Node<T> *currenta=a->first;
   for(int i=0;i<a->length-1;i++){
      currenta=currenta->next;
   }
   b->first=currenta->next;
   currenta->next=NULL;
   a=sort_ascending_r(a,false);
   b=sort_ascending_r(b,false);
   Linked_List<T> *result=merge_ascending(a,b);
   b->length=0;
   b->first=NULL;
   delete b;
   if(!last){
      sortee->length=0;
      sortee->first=NULL;
      delete sortee;
   }
   return result;
}


/*********************************************************************  
 ** Function: Linked_List
 ** Description: Default constructor
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Empty linked list constructed.
 *********************************************************************/ 
template<typename T>
Linked_List<T>::Linked_List(){
   length=0;
   first=NULL;
}

/*********************************************************************  
 ** Function: ~Linked_List()
 ** Description: Linked list destructor
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Memory allocated to the list has been freed.
 *********************************************************************/ 
template<typename T>
Linked_List<T>::~Linked_List(){
   this->clear();
}

/*********************************************************************  
 ** Function: Linked_List
 ** Description: Copy constructor
 ** Parameters: old_obj
 ** Pre-Conditions: length of old_obj is correct
 ** Post-Conditions: exact copy of list has been constructed
 *********************************************************************/ 
template<typename T>
Linked_List<T>::Linked_List(const Linked_List &old_obj){
   length=old_obj.length;
   first=NULL;
   Linked_List_Node<T> *current=old_obj.first;
   for(int i=0;i<length&&current!=NULL;i++){
      this->push_back(current->data);//could be very inefficient, find way to keep the place/pointer
      current=current->next;
   }
   //if(current!=NULL){
   //   throw exception;
   //}
}

/*********************************************************************  
 ** Function: operator=
 ** Description: Assignment Operator Overload
 ** Parameters: old_obj
 ** Pre-Conditions: length of old_obj is correct
 ** Post-Conditions: *this is now a copy of old_obj
 *********************************************************************/ 
template<typename T>
Linked_List<T> &Linked_List<T>::operator=(const Linked_List &old_obj){
   this->clear();
   length=old_obj.length;
   first=NULL;
   Linked_List_Node<T> *current=old_obj.first;
   for(int i=0;i<length&&current!=NULL;i++){
      this->push_back(current->data);//could be very inefficient, find way to keep the place/pointer
      current=current->next;
   }
   //if(current!=NULL){
   //   throw exception;
   //}
   return *this;
}

/*********************************************************************  
 ** Function: get_length
 ** Description: getter for length
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: returns length
 *********************************************************************/ 
template<typename T>
unsigned int Linked_List<T>::get_length() const{
   return length;
}

/*********************************************************************  
 ** Function: print
 ** Description: displays list contents to the screen
 ** Parameters: None
 ** Pre-Conditions: Length is correct
 ** Post-Conditions: all list contents have been displayed
 *********************************************************************/ 
template<typename T>
void Linked_List<T>::print() const{
   Linked_List_Node<T> *current=first;
   for(int i=0;i<length&&current!=NULL;i++){
      cout << current->data << " ";
      current=current->next;
   }
   cout << endl;
}

/*********************************************************************  
 ** Function: clear
 ** Description: Turns the list into the empty list, freeing all memory
 ** Parameters: None
 ** Pre-Conditions: Length is correct
 ** Post-Conditions: Length is 0 and first is null, empty list
 *********************************************************************/ 
template<typename T>
void Linked_List<T>::clear(){
   Linked_List_Node<T> *current=first;
   Linked_List_Node<T> *temp=NULL;
   for(int i=0;i<length&&current!=NULL;i++){
      temp=current->next;
      delete current;
      current=temp;
   }
   length=0;
   first=NULL;
}

/*********************************************************************  
 ** Function: push_front
 ** Description: Adds the value to the front of the list.
 ** Parameters: data
 ** Pre-Conditions: Length is correct
 ** Post-Conditions: 1 added to length, node with input data added to the front.
 *********************************************************************/ 
template<typename T>
unsigned int Linked_List<T>::push_front(T data){
   Linked_List_Node<T> *temp=first;
   first=new Linked_List_Node<T>;
   first->data=data;
   first->next=temp;
   length++;
   return length;
}

/*********************************************************************  
 ** Function: push_back
 ** Description: Adds the value to the back of the list.
 ** Parameters: data
 ** Pre-Conditions: Length is correct
 ** Post-Conditions: 1 added to length, node with input data added to the back.
 *********************************************************************/ 
template<typename T>
unsigned int Linked_List<T>::push_back(T data){
   if(first==NULL){
      first=new Linked_List_Node<T>;
      first->data=data;
      first->next=NULL;
   }
   else{
      Linked_List_Node<T> *current=first;
      for(int i=0;i<length-1&&current!=NULL&&current->next!=NULL;i++){
         current=current->next;
      }
      current->next=new Linked_List_Node<T>;
      current=current->next;
      current->data=data;
      current->next=NULL;
   }
   length++;
   return length;
}

/*********************************************************************  
 ** Function: insert
 ** Description: Adds the value to the spot in the list indicated by index.
 ** Parameters: data,index(index must be between 1 and length, otherwise an error will be displayed and nothing will happen.)
 ** Pre-Conditions: Length is correct, 1<=index<=length(can be added to the end but not the start.)
 ** Post-Conditions: 1 added to length, node with input data added to the middle.
 *********************************************************************/ 
template<typename T>
unsigned int Linked_List<T>::insert(T data, unsigned int index){//doesn't work for first position
   if(index>length||index<1){
      cout << "Error: Insert index out of ranged for linked list." << endl;
      return length;
   }
   Linked_List_Node<T> *current=first;
   for(int i=0;i<index-1;i++){
      current=current->next;
   }
   Linked_List_Node<T> *temp=current->next;
   current->next=new Linked_List_Node<T>;
   current=current->next;
   current->data=data;
   current->next=temp;
   length++;
   return length;
}

/*********************************************************************  
 ** Function: sort_ascending
 ** Description: Sorts the list in ascending order using a recursive Merge Sort
 ** Parameters: None
 ** Pre-Conditions: Length is correct.
 ** Post-Conditions: List has been sorted in ascending order.
 *********************************************************************/ 
template<typename T>
void Linked_List<T>::sort_ascending(){//implement with Merge Sort
   if(length<=1) return;
   Linked_List<T> *result=sort_ascending_r(this,true);
   this->first=result->first;
   this->length=result->length;
   result->length=0;
   result->first=NULL;
   delete result;
}

/*********************************************************************  
 ** Function: sort_descending
 ** Description: Sorts the list in descending order using a recursive Selection Sort
 ** Parameters: None
 ** Pre-Conditions: Length is correct.
 ** Post-Conditions: List has been sorted in descending order.
 *********************************************************************/ 
//it took me hours to properly implement sort_ascending. It took me less than 10 minutes to implement this function. 
//It was probably easier to program the function this way than it would have been to copy my existing implementation of sort_ascending over to this function.
template<typename T>//holy **** was this function easier
void Linked_List<T>::sort_descending(){//implement with recursive Selection Sort
   if(length<=1)
      return;
   Linked_List_Node<T> *current=first;
   Linked_List_Node<T> *maximum=first;
   for(int i=0;i<length;i++){
      if(current->data>maximum->data)
	 maximum=current;
      current=current->next;
   }
   if(first==maximum)
      first=maximum->next;
   else{
      current=first;
      while(current->next!=maximum)
	 current=current->next;
      current->next=maximum->next;
   }
   length--;
   this->sort_descending();
   current=first;//current used as temp here
   first=maximum;
   maximum->next=current;
   length++;
}

/*********************************************************************  
 ** Function: get_num_primes
 ** Description: returns the number of primes in the list(negatives are not prime)
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Number of primes has been returned.
 *********************************************************************/ 
template<typename T>
unsigned int Linked_List<T>::get_num_primes(){
   unsigned int total=0;
   Linked_List_Node<T> *current=first;
   for(int i=0;i<length;i++){
      if(is_prime(current->data))
	 total++;
      current=current->next;
   }
   return total;
}

//instantiations of the templates so that they will compile in a seperate file from the header.
template class Linked_List<int>;
template class Linked_List<unsigned int>;

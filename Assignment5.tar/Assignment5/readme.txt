/*
#include"node.h"
LOL this file is literally useless but I'll keep it around for the lulz
template class Linked_List_Node<int>;
*/
-The grave of node.cpp, a file with no real aim.

README:
This program implements a singly linked list.
Much of the required functionality of that linked list is demonstrated in the application contained in prog.cpp, but some, such as insert(), is not.
Few of the Linked_List member functions were used in sorting, because they(particularly push_back and insert) are inefficient as they must all start from the beginning of the list each time they are called.
There is a commented-out section in main(), which was used for testing purposes, which is intended to make use of the rest of the functionality, to demonstrate that it works.
To test it, simply comment it back in and run the program.
If that section is not a sufficient demonstration, you may add more commands there. No member functions with properly typed input should be able to crash the program.

The extra-credit functionality of allowing either a signed or unsigned int was implemented. This is why all of the functions in list.cpp, and both classes, are templated.
This is also why the some of the member functions of Linked_List are not *exactly* as specified: they use a template type representing int or unsigned int in place of an int.
This is also why most of the prog.cpp code is repeated twice in two seperate functions: I didn't know a better way to dynamically determine the template parameter.
This functionality is easy to use as it is the first question that comes up upon running the program.

The extra-credit implementation of recursive selection sort for sorting in descending order was also implemented.
That is why the descending sorting algorithm is much simpler, but less efficient(in theory, I haven't actually done efficiency testing.)

The node class has only a header file and not an implementation file, because it has nothing to implement. 
Since the variables of the node class are declared public, and there's not any complex functionalities that involve only a single node, everything is handled by the Linked_List class instead.
This readme file is written in the file that used to be node.cpp. All it did was include node.h and instantiate all 0 template functions in the file.

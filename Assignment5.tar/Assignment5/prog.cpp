/*********************************************************************  
 ** Program: prog.cpp(Linked List application) 
 ** Author: ProgrammersApprentice(Andrew Sauer)
 ** Date: 6/9/19
 ** Description: Implementation of singly linked list class, and application which recieves numerical input, puts it into the list, sorts the list either in ascending or descending order depending upon choice, then displays the list, its length and the number of primes in the list.
 ** Input: User decisions and numbers.
 ** Output: Input prompts, sorted list contents, list length and number of primes.
 *********************************************************************/ 

#include<iostream>
#include<cstdlib>
#include<ctime>
#include"node.h"
#include"list.h"
#include"review.h"

#define TYPE int

/*********************************************************************  
 ** Function: main_signed
 ** Description: Signed version of main because I couldn't figure out a better way to dynamically determine the type instantiated in a template
 ** Parameters: None
 ** Pre-Conditions: Signed int has been chosen
 ** Post-Conditions: None
 *********************************************************************/ 
void main_signed(){
   Linked_List<int> l;
   bool go=true;//should the program continue?
   while(go){
      bool another_num=true;
      while(another_num){
         l.push_back(get_int("Enter a number: ","That's not a valid int."));
	 another_num=yes_no("Do you want another number?","Please answer 'Yes' or 'No'.");
      }
      if(yes_no("Sort ascending?(No means sort descending.)","Please enter 'Yes' or 'No'."))
	 l.sort_ascending();
      else
	 l.sort_descending();
      l.print();
      cout << "The list length is " << l.get_length() << "." << endl;
      cout << "You have " << l.get_num_primes() << " primes in your list." << endl;
      l.clear();
      go=yes_no("Do you want to do this again?","Please enter 'Yes' or 'No'.");
   }
}

/*********************************************************************  
 ** Function: main_unsigned
 ** Description: Unsigned version of main for same reason as above
 ** Parameters: None
 ** Pre-Conditions: Unsigned int has been chosen
 ** Post-Conditions: None
 *********************************************************************/ 
void main_unsigned(){
   Linked_List<unsigned int> l;
   bool go=true;//should the program continue?
   while(go){
      bool another_num=true;
      while(another_num){
         l.push_back(get_positive_int("Enter a number: ","That's not a valid unsigned int."));
	 another_num=yes_no("Do you want another number?","Please answer 'Yes' or 'No'.");
      }
      if(yes_no("Sort ascending?(No means sort descending.)","Please enter 'Yes' or 'No'."))
	 l.sort_ascending();
      else
	 l.sort_descending();
      l.print();
      cout << "The list length is " << l.get_length() << "." << endl;
      cout << "You have " << l.get_num_primes() << " primes in your list." << endl;
      l.clear();
      go=yes_no("Do you want to do this again?","Please enter 'Yes' or 'No'.");
   }
}

/*********************************************************************  
 ** Function: main
 ** Description: Executes the program. Most of the application is in the mains above. All this does is ask the user whether the int should be signed or unsigned.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Dynamic memory freed
 *********************************************************************/ 
int main(){
   srand(time(NULL));
/*
   Linked_List<TYPE> l;
   l.print();
   l.push_back(1);
   l.print();
   l.push_front(2);
   l.push_front(3);
   l.push_back(4);
   l.print();
   l.clear();
   l.push_front(5);
   l.print();
   l.push_back(6);
   l.insert(7,0);
   l.insert(7,2);
   l.insert(10,1000);
   l.insert(7,1);
   l.print();
   l.clear();
   for(int i=0;i<31;i++){
      l.push_front(rand()%100);
   }
   l.sort_ascending();
   l.print();
*/
   bool is_signed=yes_no("Do you want the ints to be signed?","Please enter 'Yes' or 'No'.");
   if(is_signed)
      main_signed();
   else
      main_unsigned();
   return 0;
}

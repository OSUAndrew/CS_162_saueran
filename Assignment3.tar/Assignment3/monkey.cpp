#include<iostream>
#include<string>
#include"monkey.h"

using namespace std;

/*********************************************************************  
 ** Function: Monkey
 ** Description: Takes in name and age, sets up the rest of the values based on the Monkey species.
 ** Parameters: name,age
 ** Pre-Conditions: age>=0
 ** Post-Conditions: Monkey created with appropriate species values, and inputted name and age.
 *********************************************************************/ 
Monkey::Monkey(string name,float age):Animal(name,"Monkey",age,15000,1,4,.1) {}

/*********************************************************************  
 ** Function: give_birth 
 ** Description: Creates and names a new age 0 Monkey.
 ** Parameters: None
 ** Pre-Conditions: Monkey has appropriate species values.
 ** Post-Conditions: Monkey created, same as the old one but with age 0 and user-inputted name.
 *********************************************************************/ 
Monkey *Monkey::give_birth(){
   cout << this->get_name() << " had a baby Monkey!" << endl;
   Monkey *result=new Monkey("defaultn",0);
   result->give_name();
   return result;
}

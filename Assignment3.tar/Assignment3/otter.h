#ifndef OTTER_H
#define OTTER_H

#include<string>
#include"animal.h"

using namespace std;

class Otter:public Animal{
   public:
      Otter(string name,float age);
      virtual Otter *give_birth() override;
};

#endif

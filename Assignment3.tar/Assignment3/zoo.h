#ifndef ZOO_H
#define ZOO_H

#include<iostream>
#include<cstdlib>
#include<string>
#include"animal.h"

using namespace std;
/*
class Zoo{
   private:
      int num_monkeys;
      Monkey *monkeys;

      int num_otters;
      Otter *otters;

      int num_meerkats;
      Meerkat *meerkats;

      int funds;
};
*/

class Zoo{
   private:
      float funds;
      float base_food_cost;
      int num_animals;
      int memory_blocks;
      Animal *animals;
      int food_quality;
   public:
      Zoo();
      ~Zoo();
      Zoo(const Zoo &);
      Zoo operator=(const Zoo &);
      
      int get_funds() const;
      void set_funds(float);
      int get_num_animals() const;
      void add_animal(const Animal &);
      void remove_animal(int);

      void add_week();
      void sicken();
      void natalize();
      void boom();//extra for monkeys
      void add_revenue();//from animals for the week
      void buy_animal(Animal &);
      void buy_animals();
      void pay_feed();
      void change_food_cost();
      void display_animals() const;
};
#endif

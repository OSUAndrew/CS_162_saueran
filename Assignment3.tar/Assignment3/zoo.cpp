#include<iostream>
#include<cstdlib>
#include<string>
#include<cmath>
#include"animal.h"
#include"monkey.h"
#include"otter.h"
#include"meerkat.h"
#include"zoo.h"
#include"review.h"

using namespace std;

/*********************************************************************  
 ** Function: Zoo
 ** Description: Zoo default constructor.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Zoo initialized all values.
 *********************************************************************/ 
Zoo::Zoo(){
   funds=100000;
   base_food_cost=40;
   num_animals=0;
   memory_blocks=1;
   animals=new Animal[10];
}

/*********************************************************************  
 ** Function: ~Zoo
 ** Description: Zoo destructor
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: All dynamic Zoo memory deleted.
 *********************************************************************/ 
Zoo::~Zoo(){
   delete [] animals;
}

/*********************************************************************  
 ** Function: Zoo
 ** Description: Zoo Copy Constructor
 ** Parameters: const Zoo & old_zoo(copied Zoo)
 ** Pre-Conditions: old_zoo values initialized
 ** Post-Conditions: new Zoo values initialized
 *********************************************************************/ 
Zoo::Zoo(const Zoo &old_zoo){
   funds=old_zoo.funds;
   base_food_cost=old_zoo.base_food_cost;
   num_animals=old_zoo.num_animals;
   memory_blocks=old_zoo.memory_blocks;
   animals=new Animal[10*memory_blocks];
   for(int i=0;i<num_animals;i++){
      animals[i]=old_zoo.animals[i];
   }
}

/*********************************************************************  
 ** Function: operator=
 ** Description: Zoo Assignment Operator Overload
 ** Parameters: const Zoo & old_zoo
 ** Pre-Conditions: old_zoo values initialized
 ** Post-Conditions: Zoo values equal to old_zoo ones
 *********************************************************************/ 
Zoo Zoo::operator=(const Zoo &old_zoo){
   funds=old_zoo.funds;
   base_food_cost=old_zoo.base_food_cost;
   num_animals=old_zoo.num_animals;
   memory_blocks=old_zoo.memory_blocks;
   if(animals)
      delete [] animals;
   animals=new Animal[10*memory_blocks];
   for(int i=0;i<num_animals;i++){
      animals[i]=old_zoo.animals[i];
   }
   return *this;
}

/*********************************************************************  
 ** Function: get_funds
 ** Description: Getter for Zoo funds variable
 ** Parameters: None
 ** Pre-Conditions: funds variable initialized
 ** Post-Conditions: returns funds
 *********************************************************************/ 
int Zoo::get_funds() const{
   return funds;
}

/*********************************************************************  
 ** Function: set_funds
 ** Description: Setter for Zoo funds variable
 ** Parameters: funds
 ** Pre-Conditions: funds input is float
 ** Post-Conditions: funds variable is set to input
 *********************************************************************/ 
void Zoo::set_funds(float funds){
   this->funds=funds;
}

/*********************************************************************  
 ** Function: get_num_animals
 ** Description: Getter for Zoo num_animals variable(setter not needed, changes when animal added or removed)
 ** Parameters: None
 ** Pre-Conditions: num_animals variable initialized and equal to the number of valid animals in the animals array
 ** Post-Conditions: returns num_animals
 *********************************************************************/ 
int Zoo::get_num_animals() const{
   return num_animals;
}

/*********************************************************************  
 ** Function: add_animal
 ** Description: Adds an animal to the array and increments num_animals. The array is allocated in blocks of 10, if there is not space, another block is allocated.
 ** Parameters: const Animal &adding(reference to the animal to be added)
 ** Pre-Conditions: memory_blocks correctly describes the number of blocks allocated to the array. Num_animals correctly describes the actual number of animals in the array.
 ** Post-Conditions: same as pre-conditions, but also animal added has been added to the array.
 *********************************************************************/ 
void Zoo::add_animal(const Animal &adding){
   if(num_animals>=10*memory_blocks){
      memory_blocks++;
      Animal *new_animals=new Animal[10*memory_blocks];
      for(int i=0;i<num_animals;i++){
         new_animals[i]=animals[i];
      }
      delete [] animals;
      animals=new_animals;
   }
   animals[num_animals]=adding;
   num_animals++;
}

/*********************************************************************  
 ** Function: remove_animal
 ** Description: Removes the animal at an index, by overwriting it with the next animal, doing the same to the next slot, and so on until the end. decrements num_animals.
 ** Parameters: index(index of animal to be removed in the array)
 ** Pre-Conditions: num_animals correctly describes the actual number of animals in the array.
 ** Post-Conditions: same as pre-conditions, but also animal has been subtracted from the array.
 *********************************************************************/ 
void Zoo::remove_animal(int index){
   num_animals--;
   for(int i=index;i<num_animals;i++){
      animals[i]=animals[i+1];
   }
}

/*********************************************************************  
 ** Function: add_week
 ** Description: Adds one week to the age of every animal in the zoo.
 ** Parameters: None
 ** Pre-Conditions: num_animals matches actual number.
 ** Post-Conditions: ages have been incremented.
 *********************************************************************/ 
void Zoo::add_week(){
   for(int i=0;i<num_animals;i++){
      animals[i].increment_age();
   }
}

/*********************************************************************  
 ** Function: sicken
 ** Description: Has a chance of sickening each animal based on food quality, if this happens then subracts the funds required or kills the animal if not enough.
 ** Parameters: None
 ** Pre-Conditions: num_animals matches, food_quality in range 0-2
 ** Post-Conditions: None
 *********************************************************************/ 
void Zoo::sicken(){
   for(int i=0;i<num_animals;i++){
      if((food_quality==0&&rand()%25==0)||(food_quality==1&&rand()%50==0)||(food_quality==2&&rand()%100==0)){
	 float old_funds=funds;
         funds-=animals[i].sick_cost();
         if(funds<=0){
            funds=old_funds;
	    cout << "You could not pay, so " << animals[i].get_name() << " died." << endl;
	    remove_animal(i);
	 }
      }
   }
}

/*********************************************************************  
 ** Function: natalize
 ** Description: Has a 1/50 chance of each animal over 2 years giving birth, to fertility number of babies.
 ** Parameters: None
 ** Pre-Conditions: num_animals matches
 ** Post-Conditions: babies are aged 0
 *********************************************************************/ 
void Zoo::natalize(){
   for(int i=0;i<num_animals;i++){
      if(rand()%50==0&&animals[i].get_age()>=104){
	 for(int j=0;j<animals[i].get_fertility();j++){
	    Animal *added=(animals[i].give_birth());
            add_animal(*added);
	    delete added;
	 }
      }
   }
}

/*********************************************************************  
 ** Function: boom
 ** Description: Gives a 1/3 chance of the zoo getting a boom, and adds a random number from 300-700 for each Monkey.
 ** Parameters: None
 ** Pre-Conditions: num_animals matches
 ** Post-Conditions: None
 *********************************************************************/ 
void Zoo::boom(){
   if(rand()%3==0){
      cout << "The zoo recieved a boom in attendance!" << endl;
      for(int i=0;i<num_animals;i++){
         if(animals[i].get_species()=="Monkey"){
	    funds+=300;
	    funds+=rand()%400;
	 }
      }
      cout << "You now have $" << funds << "!" << endl;
   }
}

/*********************************************************************  
 ** Function: add_revenue
 ** Description: Gives you revenue for each animal you have.
 ** Parameters: None
 ** Pre-Conditions: num_animals matches
 ** Post-Conditions: None
 *********************************************************************/ 
void Zoo::add_revenue(){
   cout << "Making money..." << endl;
   for(int i=0;i<num_animals;i++){
      funds+=animals[i].revenue();
   }
   cout << "You now have $" << funds << "!" << endl;
}

/*********************************************************************  
 ** Function: buy_animal
 ** Description: Buys and names a single animal if the zoo can afford it.
 ** Parameters: Animal &a(reference to animal to be bought)
 ** Pre-Conditions: All variables in a are initialized except perhaps for the name.
 ** Post-Conditions: a has been added to animals and funds have been subtracted, if a is affordable.
 *********************************************************************/ 
void Zoo::buy_animal(Animal &a){
   funds-=a.get_cost();
   if(funds>0){
      a.give_name();
      add_animal(a);
   }
   else{
      funds+=a.get_cost();
      cout << "You can't afford it!" << endl;
   }
}

/*********************************************************************  
 ** Function: buy_animals
 ** Description: Asks the user what kind of animal to buy then how many to buy, then buys as many as can be afforded.
 ** Parameters: None
 ** Pre-Conditions: num_animals matches
 ** Post-Conditions: Animals have been bought and added, or not if they picked 0.
 *********************************************************************/ 
void Zoo::buy_animals(){
   string species;
   int num;
   cout << "What type of animal do you want to buy?(Monkey,Otter,or Meerkat)" << endl;
   while(1){
      getline(cin,species);
      if(case_insens_compare(species,"Monkey")){
         num=get_ranged_int(0,2,"How many?(0-2)","That's not valid.");
         for(int i=0;i<num;i++){
	    Monkey m("defaultn",104);
            buy_animal(m);
	 }
	 break;
      }
      else if(case_insens_compare(species,"Otter")){
         num=get_ranged_int(0,2,"How many?(0-2)","That's not valid.");
	 for(int i=0;i<num;i++){
	    Otter o("defaultn",104);
	    buy_animal(o);
	 }
	 break;
      }
      else if(case_insens_compare(species,"Meerkat")){
         num=get_ranged_int(0,2,"How many?(0-2)","That's not valid.");
	 for(int i=0;i<num;i++){
	    Meerkat k("defaultn",104);
            buy_animal(k);
	 }
	 break;
      }
      else cout << "That's not valid." << endl;
   }
   cout << "You now have $" << funds << endl;
}

/*********************************************************************  
 ** Function: pay_feed
 ** Description: Pays for feed at a rate determined by the quality bought and the base cost and the type of animal.
 ** Parameters: None
 ** Pre-Conditions: num_animals matches
 ** Post-Conditions: funds have been subtracted for feed.
 *********************************************************************/ 
void Zoo::pay_feed(){
   food_quality=get_ranged_int(0,2,"Would you like the cheap feed(0),the normal feed(1),or the expensive feed(2)?","That's not valid.");
   for(int i=0;i<num_animals;i++){
      funds-=animals[i].food_cost(pow(2,food_quality)*base_food_cost/2.0);
   }
   cout << "You now have $" << funds << "!" << endl;
}

/*********************************************************************  
 ** Function: change_food_cost
 ** Description: base feed cost is changed by a random amount, logarithmically scaled here so as to not bias the change upwards or downwards.
 ** Parameters: None
 ** Pre-Conditions: base_food_cost a valid float
 ** Post-Conditions: it has been changed randomly within a certain multiplier range(4/5-5/4)
 *********************************************************************/ 
void Zoo::change_food_cost(){
   float x=rand()/(float(RAND_MAX));
   float multiplier=pow(10.0,log10(.8)+x*(log10(1.25)-log10(.8)));
   base_food_cost=base_food_cost*multiplier;
   cout << "Normal feed now costs $" << base_food_cost << " per Meerkat." << endl;
}

/*********************************************************************  
 ** Function: display_animals
 ** Description: Displays all animals' names, species, and age.
 ** Parameters: None
 ** Pre-Conditions: num_animals matches
 ** Post-Conditions: None
 *********************************************************************/ 
void Zoo::display_animals() const{
   for(int i=0;i<num_animals;i++){
      cout << animals[i].get_name() << ", " << animals[i].get_species() << ", " << animals[i].get_age() << " weeks." << endl;
   }
}

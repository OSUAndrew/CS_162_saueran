/**************************************************
 * Program: app.cpp(Zoo Tycoon)
 * Author: ProgrammersApprentice
 * Date: 05/12/2019
 * Description: Run a zoo, buy animals, make profit, and prevent all your animals from dying of disease!(Easier than it sounds)
 * Input: Commands about the quality food to buy, what type and how many animals to buy, name of each animal, whether to quit.
 * Output: Partially random revenue, costs, notification of animal sickness and animals giving birth, game messages.
 ************************************************/

#include<iostream>
#include<cstdlib>
#include<ctime>
#include"zoo.h"
#include"review.h"

using namespace std;


/*********************************************************************  
 ** Function: main
 ** Description: Runs the program. Does zoo operations in order until the user decides to quit(prompt for quitting every 4 weeks) or goes bankrupt.
 ** Parameters: None
 ** Pre-Conditions: None 
 ** Post-Conditions: User has decided to quit or has run out of funds.
 *********************************************************************/ 
int main(){
   srand(time(NULL));

   Zoo z;
   bool quit=false;
   int round=0;
   while(z.get_funds()>0&&!quit){
      z.add_week();
      z.sicken();
      z.natalize();
      z.boom();
      z.add_revenue();
      z.buy_animals();
      z.pay_feed();
      z.change_food_cost();
      z.display_animals();
      round++;
      if(round%4==0)
         quit=yes_no("Do you want to quit?(yes/no)","Please answer 'Yes' or 'No'.");
   }
   if(z.get_funds()<=0)
      cout << "You went bankrupt! You lose!" << endl;

   return 0;
}

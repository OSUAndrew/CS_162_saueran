#ifndef MONKEY_H
#define MONKEY_H

#include<string>
#include"animal.h"

using namespace std;

class Monkey:public Animal{
   public:
      Monkey(string name,float age);
      virtual Monkey *give_birth() override;
};

#endif

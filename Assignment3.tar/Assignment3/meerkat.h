#ifndef MEERKAT_H
#define MEERKAT_H

#include<string>
#include"animal.h"

using namespace std;

class Meerkat:public Animal{
   public:
      Meerkat(string name,float age);
      virtual Meerkat *give_birth() override;
};

#endif

#include<iostream>
#include<cstdlib>
#include<string>
#include"animal.h"

using namespace std;

/*********************************************************************  
 ** Function: Animal
 ** Description: Default Animal Constructor.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: Animal values initialized.
 *********************************************************************/ 
Animal::Animal(){
   name="defaultn";
   species="defaults";
   age=0;
   cost=0;
   fertility=0;
   food_mult=0;
   rev_percent=0;
}

/*********************************************************************  
 ** Function: Animal
 ** Description: Animal Constructor with Params
 ** Parameters: name,species,age,cost,fertility,food_mult,rev_percent
 ** Pre-Conditions: species="Monkey","Otter",or"Meerkat";age>=0;cost>0;fertility>0;food_mult>0;0<rev_percent<1
 ** Post-Conditions: Animal constructed with all input values.
 *********************************************************************/ 
Animal::Animal(string name, string species, float age, float cost, float fertility, float food_mult, float rev_percent){
   this->name=name;
   this->species=species;
   this->age=age;
   this->cost=cost;
   this->fertility=fertility;
   this->food_mult=food_mult;
   this->rev_percent=rev_percent;
}
/*
Animal::~Animal(){}

Animal::Animal(const Animal &old_obj){
   name=old_obj.name;
   species=old_obj.species;
   age=old_obj.age;
   cost=old_obj.cost;
   fertility=old_obj.fertility;
   food_mult=old_obj.food_mult;
   rev_percent=old_obj.rev_percent;
}

Animal &Animal::operator=(const Animal &old_obj){
   name=old_obj.name;
   species=old_obj.species;
   age=old_obj.age;
   cost=old_obj.cost;
   fertility=old_obj.fertility;
   food_mult=old_obj.food_mult;
   rev_percent=old_obj.rev_percent;
}
*/

/*********************************************************************  
 ** Function: get_name
 ** Description: Getter for name
 ** Parameters: None
 ** Pre-Conditions: Name initialized
 ** Post-Conditions: returns name
 *********************************************************************/ 
string Animal::get_name() const{
   return name;
}

/*********************************************************************  
 ** Function: set_name
 ** Description: Setter for name
 ** Parameters: name
 ** Pre-Conditions: None
 ** Post-Conditions: Name has been set to input.
 *********************************************************************/ 
void Animal::set_name(string name){
   this->name=name;
}

/*********************************************************************  
 ** Function: get_species
 ** Description: Getter for species(setter not needed, species set at construction)
 ** Parameters: None
 ** Pre-Conditions: Species initialized
 ** Post-Conditions: returns species
 *********************************************************************/ 
string Animal::get_species() const{
   return species;
}

/*********************************************************************  
 ** Function: get_age
 ** Description: Getter for age
 ** Parameters: None
 ** Pre-Conditions: Age initialized
 ** Post-Conditions: returns age
 *********************************************************************/ 
float Animal::get_age() const{
   return age;
}

/*********************************************************************  
 ** Function: set_age
 ** Description: Setter for age
 ** Parameters: age
 ** Pre-Conditions: None
 ** Post-Conditions: Age has been set to input.
 *********************************************************************/ 
void Animal::set_age(float age){
   this->age=age;
}

/*********************************************************************  
 ** Function: get_cost
 ** Description: Getter for cost(setter not needed, cost set at construction)
 ** Parameters: None
 ** Pre-Conditions: Cost initialized
 ** Post-Conditions: returns cost
 *********************************************************************/ 
float Animal::get_cost() const{
   return cost;
}

/*********************************************************************  
 ** Function: get_fertility
 ** Description: Getter for fertility(setter not needed, fertility set at construction)
 ** Parameters: None
 ** Pre-Conditions: Fertility initialized
 ** Post-Conditions: returns fertility
 *********************************************************************/ 
float Animal::get_fertility() const{
   return fertility;
}

/*********************************************************************  
 ** Function: get_food_mult
 ** Description: Getter for food_mult(setter not needed, food_mult set at construction)
 ** Parameters: None
 ** Pre-Conditions: Food_mult initialized
 ** Post-Conditions: returns food_mult
 *********************************************************************/ 
float Animal::get_food_mult() const{
   return food_mult;
}

/*********************************************************************  
 ** Function: get_rev_percent
 ** Description: Getter for rev_percent(setter not needed, rev_percent set at construction)
 ** Parameters: None
 ** Pre-Conditions: Rev_percent initialized
 ** Post-Conditions: returns rev_percent
 *********************************************************************/ 
float Animal::get_rev_percent() const{
   return rev_percent;
}

/*********************************************************************  
 ** Function: give_name
 ** Description: Gives the animal a name based on user input.
 ** Parameters: None
 ** Pre-Conditions: None
 ** Post-Conditions: name has been initialized by user.
 *********************************************************************/ 
void Animal::give_name(){
   cout << "What is the " << species <<"'s name?" << endl;
   getline(cin,name);
}

/*********************************************************************  
 ** Function: increment_age
 ** Description: Adds one week to the animal's age.
 ** Parameters: None
 ** Pre-Conditions: Age initialized
 ** Post-Conditions: Age has been incremented.
 *********************************************************************/ 
void Animal::increment_age(){
   age+=1.0;
}

/*********************************************************************  
 ** Function: sick_cost
 ** Description: Makes an animal sick and determines the cost to heal it based on whether it is a baby and the initial cost.
 ** Parameters: None
 ** Pre-Conditions: Age, name initialized.
 ** Post-Conditions: None.
 *********************************************************************/ 
float Animal::sick_cost() const{
   cout << name << " is deathly ill..." << endl;
   float result=cost;
   if(age<5.0){
      result=result*2.0;
   }
   result=result/2.0;
   cout << "It will cost $" << result << " to heal." << endl;
   return result;
}

/*********************************************************************  
 ** Function: give_birth
 ** Description: Creates a new animal with the attributes of the old one but named by user and aged 0.
 ** Parameters: None
 ** Pre-Conditions: Animal's age >=104.
 ** Post-Conditions: Returned baby is aged 0 and named by user.
 *********************************************************************/ 
Animal *Animal::give_birth(){
   cout << name << " had a baby " << species << "!" << endl;
   Animal *result=new Animal;
   (*result)=(*this);
   result->give_name();
   result->set_age(0);
   return result;
}

/*********************************************************************  
 ** Function: revenue
 ** Description: Determines the amount of revenue the animal will generate each round based on its age, cost and rev_percent.
 ** Parameters: None
 ** Pre-Conditions: cost,rev_percent,age initialized
 ** Post-Conditions: None
 *********************************************************************/ 
float Animal::revenue(){
   float result=cost*rev_percent;
   if(age<5.0){
      result=result*2.0;
   }
   return result;
}

/*********************************************************************  
 ** Function: food_cost
 ** Description: Determines the food cost for the animal based on the base cost and the animal's own multiplier.
 ** Parameters: base(base food cost which is passed in and depends on the true base and food quality.)
 ** Pre-Conditions: base>0,food_mult>0
 ** Post-Conditions: returns base*food_mult
 *********************************************************************/ 
float Animal::food_cost(float base){
   return base*food_mult;
}

#include<iostream>
#include<cstdlib>
#include<cstring>
#include"review.h"

using namespace std;

/*********************************************************************  
 ** Function: is_positive_int
 ** Description: Takes in a c-string and determines whether it represents a non-negative integer.
 ** Parameters: char*c
 ** Pre-Conditions: c is null-terminated
 ** Post-Conditions: returns 1 if it is a non-negative integer, returns 0 otherwise.
 *********************************************************************/ 
int is_positive_int(char*c){
   //int is_zero=1;
   for(int i=0;c[i]!='\0';i++){
      if(!(c[i]<='9'&&c[i]>='0')) return 0;
      //if(c[i]!='0') is_zero=0;
   }
   return 1;
}

/*********************************************************************  
 ** Function: get_positive_int
 ** Description: Prompts a user for a nonnegative int until they enter a valid one.
 ** Parameters: prompt,nag(message if invalid input entered)
 ** Pre-Conditions: None
 ** Post-Conditions: returns nonnegative int given by user.
 *********************************************************************/ 
int get_positive_int(string prompt,string nag){
   cout << prompt << endl;
   char* str=new char[20];
   cin.getline(str,20);
   while(!is_positive_int(str)){
      cout << nag << endl;
      cin.getline(str,20);
   }
   int result=atoi(str);
   delete [] str;
   return result;
}

/*********************************************************************  
 ** Function: get_ranged_int
 ** Description: Gets an int in range from low to high.
 ** Parameters: low,high,prompt,nag
 ** Pre-Conditions: high>low
 ** Post-Conditions: returns int between low and high inclusive, given by user.
 *********************************************************************/ 
int get_ranged_int(int low, int high, string prompt, string nag){
   int result=-1;
   while(!(result>=low&&result<=high)){
      result=get_positive_int(prompt,nag);
      if(!(result>=low&&result<=high)){
         cout << "Out of range value" << endl;
      }
   }
   return result;
}

/*********************************************************************  
 ** Function: is_case_insensitive_equal
 ** Description: Determines if two characters are the same letter, even if they are not the same case.
 ** Parameters: a,b
 ** Pre-Conditions: None
 ** Post-Conditions: returns true if equal, false if not.
 *********************************************************************/ 
bool is_case_insensitive_equal(char a, char b){
   if(a==b){
      return true;
   }
   if(a>='A'&&a<='Z'&&b==a+32){
      return true;
   }
   if(b>='A'&&b<='Z'&&a==b+32){
      return true;
   }
   return false;
}

/*********************************************************************  
 ** Function: case_insens_compare
 ** Description: Compares two strings to determine whether they are case-insensitively the same.
 ** Parameters: a,b
 ** Pre-Conditions: None
 ** Post-Conditions: returns true if equal, false if not.
 *********************************************************************/ 
bool case_insens_compare(string a, string b){
   if(a.length()!=b.length()){
      return false;
   }
   for(int i=0;i<a.length();i++){
      if(!is_case_insensitive_equal(a.at(i),b.at(i))){
         return false;
      }
   }
   return true;
}

/*********************************************************************  
 ** Function: yes_no
 ** Description: Gets user input in the form of answer to a yes/no question(case-insensitive).
 ** Parameters: prompt,nag
 ** Pre-Conditions: None
 ** Post-Conditions: Returns true if yes, false if no.
 *********************************************************************/ 
bool yes_no(string prompt,string nag){
   cout << prompt << endl;
   string str;
   getline(cin,str);
   while(!(case_insens_compare(str,"yes")||case_insens_compare(str,"no"))){
      cout << nag << endl;
      getline(cin,str);
   }
   if(case_insens_compare(str,"yes")) return true;
   else return false;
}

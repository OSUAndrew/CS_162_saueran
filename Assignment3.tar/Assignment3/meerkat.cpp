#include<iostream>
#include<string>
#include"meerkat.h"

using namespace std;

/*********************************************************************  
 ** Function: Meerkat
 ** Description: Takes in name and age, sets up the rest of the values based on the Meerkat species.
 ** Parameters: name,age
 ** Pre-Conditions: age>=0
 ** Post-Conditions: Meerkat created with appropriate species values, and inputted name and age.
 *********************************************************************/ 
Meerkat::Meerkat(string name,float age):Animal(name,"Meerkat",age,500,5,1,.05) {}

/*********************************************************************  
 ** Function: give_birth
 ** Description: Creates and names a new age 0 Meerkat.
 ** Parameters: None
 ** Pre-Conditions: Meerkat has appropriate species values.
 ** Post-Conditions: Meerkat created, same as the old one but with age 0 and user-inputted name.
 *********************************************************************/ 
Meerkat *Meerkat::give_birth(){
   cout << this->get_name() << " had a baby Meerkat!" << endl;
   Meerkat *result=new Meerkat("defaultn",0);
   result->give_name();
   return result;
}

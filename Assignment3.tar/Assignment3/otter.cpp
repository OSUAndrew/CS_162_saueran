#include<iostream>
#include<string>
#include"otter.h"

using namespace std;

/*********************************************************************  
 ** Function: Otter
 ** Description: Takes in name and age, sets up the rest of the values based on the Otter species.
 ** Parameters: name,age
 ** Pre-Conditions: age>=0
 ** Post-Conditions: Otter created with appropriate species values, and inputted name and age.
 *********************************************************************/ 
Otter::Otter(string name,float age):Animal(name,"Otter",age,5000,2,2,.05) {}

/*********************************************************************  
 ** Function: give_birth 
 ** Description: Creates and names a new age 0 Otter.
 ** Parameters: None
 ** Pre-Conditions: Otter has appropriate species values.
 ** Post-Conditions: Otter created, same as the old one but with age 0 and user-inputted name.
 *********************************************************************/ 
Otter *Otter::give_birth(){
   cout << this->get_name() << " had a baby Otter!" << endl;
   Otter *result=new Otter("defaultn",0);
   result->give_name();
   return result;
}

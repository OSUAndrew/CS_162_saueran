#ifndef ANIMAL_H
#define ANIMAL_H

#include<iostream>
#include<cstdlib>
#include<string>

using namespace std;

class Animal{
   private:
      string name;
      string species;
      float age;
      float cost;
      float fertility;
      float food_mult;
      float rev_percent;
   public:
      Animal();
      Animal(string,string,float,float,float,float,float);
      /*Not needed
      ~Animal();
      Animal(const Animal &);
      Animal &operator=(const Animal &);
      */
      string get_name() const;
      void set_name(string);
      string get_species() const;
      float get_age() const;
      void set_age(float);
      float get_cost() const;
      float get_fertility() const;
      float get_food_mult() const;
      float get_rev_percent() const;
      
      void give_name();
      void increment_age();
      float sick_cost() const;
      virtual Animal *give_birth();//to only one animal
      float revenue();
      float food_cost(float base);
};

#endif

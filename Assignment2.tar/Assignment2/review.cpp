#include<iostream>
#include<cstdlib>
#include<cstring>
#include"review.hpp"

using namespace std;

int is_positive_int(char*c){
   int is_zero=1;
   for(int i=0;c[i]!='\0';i++){
      if(!(c[i]<='9'&&c[i]>='0')) return 0;
      if(c[i]!='0') is_zero=0;
   }
   return !is_zero;
}

int get_positive_int(string prompt,string nag){
   cout << prompt << endl;
   char* str=new char[20];
   cin.getline(str,20);
   while(!is_positive_int(str)){
      cout << nag << endl;
      cin.getline(str,20);
   }
   int result=atoi(str);
   delete [] str;
   return result;
}

long get_positive_long(string prompt, string nag){
   cout << prompt << endl;
   char* str=new char[20];
   cin.getline(str,20);
   while(!is_positive_int(str)){
      cout << nag << endl;
      cin.getline(str,20);
   }
   int result=atol(str);
   delete [] str;
   return result; 
}

bool is_case_insensitive_equal(char a, char b){
   if(a==b){
      return true;
   }
   if(a>='A'&&a<='Z'&&b==a+32){
      return true;
   }
   if(b>='A'&&b<='Z'&&a==b+32){
      return true;
   }
   return false;
}

bool case_insens_compare(string a, string b){
   if(a.length()!=b.length()){
      return false;
   }
   for(int i=0;i<(int)(a.length());i++){
      if(!is_case_insensitive_equal(a.at(i),b.at(i))){
         return false;
      }
   }
   return true;
}

bool yes_no(string prompt,string nag){
   cout << prompt << endl;
   string str;
   getline(cin,str);
   while(!(case_insens_compare(str,"yes")||case_insens_compare(str,"no"))){
      cout << nag << endl;
      getline(cin,str);
   }
   if(case_insens_compare(str,"yes")) return true;
   else return false;
}

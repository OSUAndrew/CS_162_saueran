#ifndef INTERFACE_H
#define INTERFACE_H

#include<iostream>
#include<cstdlib>
#include"pizza_classes.hpp"

using namespace std;

void customer_loop(Restaurant &);
void employee_loop(Restaurant &);

#endif

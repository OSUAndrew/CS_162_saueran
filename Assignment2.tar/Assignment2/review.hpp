#ifndef REVIEW_H
#define REVIEW_H

#include<iostream>
#include<cstdlib>
#include<cstring>

using namespace std;

int is_positive_int(char *);

int get_positive_int(string, string);

long get_positive_long(string, string);

bool is_case_insensitive_equal(char, char);
 
bool case_insens_compare(string, string);

bool yes_no(string,string);

#endif

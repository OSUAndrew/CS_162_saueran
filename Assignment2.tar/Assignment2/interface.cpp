#include<iostream>
#include<cstdlib>
#include<string>
#include"review.hpp"
#include"interface.hpp"
#include"pizza_classes.hpp"

using namespace std;


/**********************************************************************************************
 * Function: customer_choices
 * Description: Displays the customer's choices and gets a decision in the form of an int.
 * Parameters: None
 * Pre-conditions: user has entered the customer section
 * Post-conditions: None
 *********************************************************************************************/
int customer_choices(){
   int result=0;
   cout << "What would you like to do?" << endl;
   cout << "1) View Menu" << endl;
   cout << "2) Search by Cost" << endl;
   cout << "3) Search by Ingredients" << endl;
   cout << "4) Place Order" << endl;
   cout << "5) View Hours" << endl;
   cout << "6) View Address" << endl;
   cout << "7) View Phone" << endl;
   cout << "8) Logout" << endl;
   while(!(result>=1&&result<=8)){
      result=get_positive_int("","That's not a valid choice.");
      if(!(result>=1&&result<=8)){
         cout << "That's not a valid choice." << endl;
      }
   }
   return result;
}

/**********************************************************************************************
 * Function: employee_choices
 * Description: Displays the employee's choices and gets a decision in the form of an int.
 * Parameters: None
 * Pre-conditions: user has logged in as employee
 * Post-conditions: None
 *********************************************************************************************/
int employee_choices(){
   int result=0;
   cout << "What would you like to do?" << endl;
   cout << "1) Change hours" << endl;
   cout << "2) View orders" << endl;
   cout << "3) Remove order" << endl;
   cout << "4) Add Item to Menu" << endl;
   cout << "5) Remove Item from Menu" << endl;
   cout << "6) View Menu" << endl;
   cout << "7) View Hours" << endl;
   cout << "8) View Address" << endl;
   cout << "9) View Phone" << endl;
   cout << "10) Logout" << endl;
   while(!(result>=1&&result<=10)){
      result=get_positive_int("","That's not a valid choice.");
      if(!(result>=1&&result<=10)){
         cout << "That's not a valid choice." << endl;
      }
   }
   return result;
}

/**********************************************************************************************
 * Function: customer_loop
 * Description: Takes an action based on the customer's choice.
 * Parameters: Restaurant &r, the restaurant this choice is being made at.
 * Pre-conditions: r has loaded in all data from files.
 * Post-conditions: None
 *********************************************************************************************/
void customer_loop(Restaurant &r){
   int choice=0;
   int quit=0;
   Order o;
   while(!quit){
      choice=customer_choices();
      switch(choice){
         case 1:
	    r.view_menu();
	    break;
	 case 2:
	    r.search_menu_by_price();
	    break;
	 case 3:
	    r.search_by_ingredients();
	    break;
	 case 4:
	    o=r.create_order(r.get_menu());
	    r.place_order(o);
	    break;
	 case 5:
	    r.view_hours();
	    break;
	 case 6:
	    r.view_address();
	    break;
	 case 7:
	    r.view_phone();
	    break;
	 case 8:
	    quit=1;
      }
   }
}

/**********************************************************************************************
 * Function: employee_loop
 * Description: Attempts to log in employee, then takes an action based on the employee's choice.
 * Parameters: Restaurant &r, the restaurant this choice is being made at.
 * Pre-conditions: r has loaded in all data from files.
 * Post-conditions: None
 *********************************************************************************************/
void employee_loop(Restaurant &r){
   int choice=0;
   int quit=0;
   int id;
   string password;
   bool access=false;
   for(int i=0;i<3;i++){
      id=get_positive_int("Please enter your employee ID.","That's not an ID number.");
      cout << "Please enter your password." << endl;
      getline(cin,password);
      access=r.login(id,password);
      if(access){
         break;
      }
   }
   while(!quit&&access){
      choice=employee_choices();
      switch(choice){
         case 1:
	    r.change_hours();
	    break;
	 case 2:
	    r.view_orders();
	    break;
	 case 3:
	    r.remove_orders();
	    break;
	 case 4:
	    r.add_to_menu();
	    break;
	 case 5:
	    r.remove_from_menu();
	    break;
         case 6:
	    r.view_menu();
	    break;
	 case 7:
	    r.view_hours();
	    break;
	 case 8:
	    r.view_address();
	    break;
	 case 9:
	    r.view_phone();
	    break;
	 case 10:
	    quit=1;
      }
   }
   if(!access){
      cout << "Failed login!" << endl;
   }
}

/************************************************************
 * Program: pizzastore
 * Author: ProgrammersApprentice
 * Date: 4/29/2019
 * Description: Simulates some features of a pizza store website. You can log in as employee or enter as customer, employees can change information while customers can place orders, among other things.
 * Input: Menu of pizzas from menu.txt, employee login information from employee.txt, restaurant information from restaurant_info.txt, order list from orders.txt
 * Output: Those same files, but modified by the operation of the program.
 ***********************************************************/

#include<iostream>
#include<cstdlib>
#include<string>
#include"pizza_classes.hpp"
#include"interface.hpp"
#include"review.hpp"

using namespace std;

int main(){
   Restaurant r;
   r.load_data();
   string response;
   cout << "Welcome to " << r.get_name() << "!" << endl;
   while(1){
      cout << "Are you a customer or employee? (or type 'q' to quit)" << endl;
      getline(cin,response);
      if(case_insens_compare("c",response)||case_insens_compare("customer",response)){
         customer_loop(r);
         r.write_data();
      }
      else if(case_insens_compare("e",response)||case_insens_compare("employee",response)){
         employee_loop(r);
	 r.write_data();
      }
      else if(case_insens_compare("q",response)||case_insens_compare("quit",response)){
         break;
      }
      else cout << "Invalid response." << endl;
   }
   return 0;
}

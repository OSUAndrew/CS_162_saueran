#include<iostream>
#include<cstdlib>
#include<fstream>
#include"pizza_classes.hpp"
#include"review.hpp"

using namespace std;

/**********************************************************************************************
 * Function: Pizza()
 * Description: Default Constructor for Pizza class.
 * Parameters: None
 * Pre-conditions: None
 * Post-conditions: Class variables are initialized.
 *********************************************************************************************/
Pizza::Pizza(){
   name="";
   small_cost=0;
   medium_cost=0;
   large_cost=0;
   num_ingredients=0;
   ingredients=NULL;
}

/**********************************************************************************************
 * Function: ~Pizza()
 * Description: Destructor for Pizza class.
 * Parameters: None
 * Pre-conditions: None
 * Post-conditions: Dynamic memory is deleted.
 *********************************************************************************************/
Pizza::~Pizza(){
   if(this->ingredients){
      delete [] ingredients;
   }
}

/**********************************************************************************************
 * Function: Pizza()
 * Description: Copy constructor for Pizza class.
 * Parameters: Pizza &old_pizza
 * Pre-conditions: None
 * Post-conditions: Duplicate of old_pizza is constructed.
 *********************************************************************************************/
Pizza::Pizza(const Pizza &old_pizza){
   name=old_pizza.name;
   small_cost=old_pizza.small_cost;
   medium_cost=old_pizza.medium_cost;
   large_cost=old_pizza.large_cost;
   num_ingredients=old_pizza.num_ingredients;
   ingredients=new string[num_ingredients];
   for(int i=0;i<num_ingredients;i++){
      ingredients[i]=old_pizza.ingredients[i];
   }
}

/**********************************************************************************************
 * Function: operator =
 * Description: Assignment operator overload for Pizza class.
 * Parameters: Pizza &old_pizza
 * Pre-conditions: None
 * Post-conditions: Pizza becomes a duplicate of &old_pizza.
 *********************************************************************************************/
void Pizza::operator = (const Pizza &old_pizza){
   name=old_pizza.name;
   small_cost=old_pizza.small_cost;
   medium_cost=old_pizza.medium_cost;
   large_cost=old_pizza.large_cost;
   num_ingredients=old_pizza.num_ingredients;
   if(this->ingredients){
      delete [] ingredients;
   }
   ingredients=new string[num_ingredients];
   for(int i=0;i<num_ingredients;i++){
      ingredients[i]=old_pizza.ingredients[i];
   }
}

/**********************************************************************************************
 * Function: get_name
 * Description: Returns the name of the pizza.
 * Parameters: None
 * Pre-conditions: None
 * Post-conditions: None
 *********************************************************************************************/
string Pizza::get_name() const{
   return name;
}

/**********************************************************************************************
 * Function: set_name
 * Description: Sets the name of the pizza to string name.
 * Parameters: string name
 * Pre-conditions: None
 * Post-conditions: None
 *********************************************************************************************/
void Pizza::set_name(string name){
   this->name=name;
}

//small=0,medium=1,large=2, -1 means error.
/**********************************************************************************************
 * Function: get_cost
 * Description: Returns the cost of the pizza in int size(0 represents small, 1 represents medium, 2 represents large).
 * Parameters: int size
 * Pre-conditions: None
 * Post-conditions: None
 *********************************************************************************************/
int Pizza::get_cost(int size) const{
   switch(size){
      case 0:
	 return small_cost;
      case 1:
	 return medium_cost;
      case 2:
	 return large_cost;
      default:
	 cout << "Invalid size passed to get_cost function in Pizza class." << endl;
	 return -1;
   }
}

/**********************************************************************************************
 * Function: set_cost
 * Description: Sets the cost of the pizza in int size.
 * Parameters: int size, int cost
 *********************************************************************************************/
void Pizza::set_cost(int size, int cost){
   switch(size){
      case 0:
	 small_cost=cost;
	 break;
      case 1:
	 medium_cost=cost;
	 break;
      case 2:
	 large_cost=cost;
	 break;
      default:
	 cout << "Invalid size passed to set_cost function in Pizza class." << endl;
   }
}

/****************************************************************
 * Description: Returns the number of ingredients in the pizza.
*****************************************************************/
int Pizza::get_num_ingredients() const{
   return num_ingredients;
}

/****************************************************************
 * Description: Gets the nth ingredient from the pizza.
 ****************************************************************/

string Pizza::get_ingredient(int n) const{
   if(n>=num_ingredients){
      cout << "Pizza::get_ingredient was passed an out of range value!" << endl;
      exit(1);
   }
   else return ingredients[n];
}

//no newlines displayed here
/****************************************************************
 * Description: Displays the ingredients to the user, as part of displaying a pizza.
 ****************************************************************/
void Pizza::display_ingredients() const{
   for(int i=0;i<num_ingredients;i++){
      cout << ingredients[i] << " ";
   }
}

/****************************************************************
 * Description: Adds an ingredient to a pizza, including incrementing the number of ingredients.
 ****************************************************************/
void Pizza::add_ingredient(string ing_name){
   num_ingredients++;
   string *new_ingredients=new string[num_ingredients];
   for(int i=0;i<num_ingredients-1;i++){
      new_ingredients[i]=ingredients[i];
   }
   new_ingredients[num_ingredients-1]=ing_name;
   if(ingredients){
      delete [] ingredients;
   }
   ingredients=new_ingredients;
}

//doesn't actually decrease the memory allocated, but terminates it with "".
/****************************************************************
 * Description: Removes an ingredient from the pizza(Don't think this was ever used).
 ****************************************************************/
void Pizza::subtract_ingredient(int n){
   if(n>=num_ingredients){
      cout << "Out of range index passed to Pizza::subtract_ingredient!" << endl;
      exit(1);
   }
   num_ingredients--;
   for(int i=n;i<num_ingredients;i++){
      ingredients[i]=ingredients[i+1];
   }
   ingredients[num_ingredients]="";
}



/****************************************************************
 * Description: Menu Default Constructor.
 ****************************************************************/
Menu::Menu(){
   num_pizzas=0;
   pizzas=NULL;
}

/****************************************************************
 * Description: Menu Destructor.
 ****************************************************************/
Menu::~Menu(){
   if(this->pizzas){
      delete [] pizzas;
   }
}

/****************************************************************
 * Description: Menu Copy Constructor.
 ****************************************************************/
Menu::Menu(const Menu &old_menu){
   num_pizzas=old_menu.num_pizzas;
   pizzas=new Pizza[num_pizzas];
   for(int i=0;i<num_pizzas;i++){
      pizzas[i]=old_menu.pizzas[i];
   }
}
/****************************************************************
 * Description: Menu Assignment Operator Overload.
 ****************************************************************/
void Menu::operator=(const Menu &old_menu){
   num_pizzas=old_menu.num_pizzas;
   if(this->pizzas){
      delete [] pizzas;
   }
   pizzas=new Pizza[num_pizzas];
   for(int i=0;i<num_pizzas;i++){
      pizzas[i]=old_menu.pizzas[i];
   }
}
/****************************************************************
 * Description: Returns the number of pizzas on the menu.
 ****************************************************************/
int Menu::get_num_pizzas() const{
   return num_pizzas;
}
/****************************************************************
 * Description: Gets a single pizza(the nth) from the menu.
 ****************************************************************/
Pizza Menu::get_menu_pizza(int n) const{
   if(n>=num_pizzas){
      cout << "Out-of-range index passed to Menu::get_menu_pizza!" << endl;
      exit(1);
   }
   else return pizzas[n];
}
/****************************************************************
 * Description: Displays the entire menu for the user.
 ****************************************************************/
void Menu::display_menu() const{
   for(int i=0;i<num_pizzas;i++){
      cout << i+1 << ") ";
      cout << pizzas[i].get_name() << " ";
      cout << pizzas[i].get_cost(0) << " ";
      if(pizzas[i].get_cost(1)){
         cout << pizzas[i].get_cost(1) << " ";
      }
      else cout << "N/A ";
      if(pizzas[1].get_cost(2)){
      cout << pizzas[i].get_cost(2) << " ";
      }
      else cout << "N/A ";
      cout << pizzas[i].get_num_ingredients() << " ";
      pizzas[i].display_ingredients();
      cout << endl;
   }
}
/****************************************************************
 * Description: Adds a pizza to the menu.
 ****************************************************************/
void Menu::add_to_menu(Pizza new_pizza){
   num_pizzas++;
   Pizza *new_pizzas=new Pizza[num_pizzas];
   for(int i=0;i<num_pizzas-1;i++){
      new_pizzas[i]=pizzas[i];
   }
   if(pizzas){
      delete [] pizzas;
   }
   new_pizzas[num_pizzas-1]=new_pizza;
   pizzas=new_pizzas;
}
/****************************************************************
 * Description: Removes a pizza from the menu.
 ****************************************************************/
void Menu::remove_from_menu(int n){
   num_pizzas--;
   if(n>num_pizzas){
      cout << "Out-of-range index passed to Menu::remove_from_menu!" << endl;
      exit(1);
   }
   for(int i=n;i<num_pizzas;i++){
      pizzas[i]=pizzas[i+1];
   }
   pizzas[num_pizzas]=Pizza();
}

//I assume that small is the cheapest.
/****************************************************************
 * Description: Searches pizzas by cost to create a new menu with only pizzas that can be purchased in small with less than upper_bound. Any size it can't be purchased in is represented as 0 cost. This is taken into account by the function create_order.
 ****************************************************************/
Menu Menu::search_pizza_by_cost(int upper_bound){
   Menu result;
   Pizza adding;
   for(int i=0;i<num_pizzas;i++){
      if(pizzas[i].get_cost(0)<=upper_bound){
	 adding=pizzas[i];
	 if(adding.get_cost(1)>upper_bound){
	    adding.set_cost(1,0);
	 }
	 if(adding.get_cost(2)>upper_bound){
	    adding.set_cost(2,0);
	 }
         result.add_to_menu(adding);
      }
   }
   return result;
}
/****************************************************************
 * Description: Creates a new menu including only the pizzas with all the ingredients on the list.
 ****************************************************************/
Menu Menu::search_pizza_by_ingredients_to_include(string *ing_list, int n){
   Menu result;
   bool good_pizza;
   bool good_ingredient;
   for(int i=0;i<num_pizzas;i++){
      good_pizza=true;
      for(int j=0;j<n;j++){
         good_ingredient=false;
	 for(int k=0;k<pizzas[i].get_num_ingredients();k++){
	    if(case_insens_compare(pizzas[i].get_ingredient(k),ing_list[j])){
	       good_ingredient=true;
	       break;
	    }
	 }
	 if(!good_ingredient){
	    good_pizza=false;
	 }
      }
      if(good_pizza){
         result.add_to_menu(pizzas[i]);
      }
   }
   return result;
}
/****************************************************************
 * Description: Creates a new menu including only the pizzas with none of the ingredients on the list.
 ****************************************************************/
Menu Menu::search_pizza_by_ingredients_to_exclude(string *ing_list, int n){
   Menu result;
   bool good_pizza;
   bool bad_ingredient;
   for(int i=0;i<num_pizzas;i++){
      good_pizza=true;
      for(int j=0;j<n;j++){
         bad_ingredient=false;
	 for(int k=0;k<pizzas[i].get_num_ingredients();k++){
	    if(case_insens_compare(pizzas[i].get_ingredient(k),ing_list[j])){
	       bad_ingredient=true;
	       break;
	    }
	 }
	 if(bad_ingredient){
	    good_pizza=false;
	 }
      }
      if(good_pizza){
         result.add_to_menu(pizzas[i]);
      }
   }
   return result;
}




Order::Order(){
   order_num=0;
   customer_name="";
   customer_cc=0;
   customer_phone=0;

   num_pizzas=0;
   numbers=NULL;
   pizzas=NULL;
   sizes=NULL;
}

Order::~Order(){
   if(numbers){
      delete [] numbers;
   }
   if(pizzas){
      delete [] pizzas;
   }
   if(sizes){
      delete [] sizes;
   }
}

Order::Order(const Order &old_order){
   order_num=old_order.order_num;
   customer_name=old_order.customer_name;
   customer_cc=old_order.customer_cc;
   customer_phone=old_order.customer_phone;

   num_pizzas=old_order.num_pizzas;
   numbers=new int[num_pizzas];
   pizzas=new Pizza[num_pizzas];
   sizes=new int[num_pizzas];
   for(int i=0;i<num_pizzas;i++){
      numbers[i]=old_order.numbers[i];
      pizzas[i]=old_order.pizzas[i];
      sizes[i]=old_order.sizes[i];
   }
}

void Order::operator=(const Order &old_order){
   order_num=old_order.order_num;
   customer_name=old_order.customer_name;
   customer_cc=old_order.customer_cc;
   customer_phone=old_order.customer_phone;

   num_pizzas=old_order.num_pizzas;
   if(numbers){
      delete [] numbers;
   }
   numbers=new int[num_pizzas];
   if(pizzas){
      delete [] pizzas;
   }
   pizzas=new Pizza[num_pizzas];
   if(sizes){
      delete [] sizes;
   }
   sizes=new int[num_pizzas];
   for(int i=0;i<num_pizzas;i++){
      numbers[i]=old_order.numbers[i];
      pizzas[i]=old_order.pizzas[i];
      sizes[i]=old_order.sizes[i];
   }
}

void Order::add_to_order(int n, int size, string pizza_name, const Menu &m){
   num_pizzas++;
   int *new_numbers=new int[num_pizzas];
   int *new_sizes=new int[num_pizzas];
   Pizza *new_pizzas=new Pizza[num_pizzas];
   for(int i=0;i<num_pizzas-1;i++){
      new_numbers[i]=numbers[i];
      new_sizes[i]=sizes[i];
      new_pizzas[i]=pizzas[i];
   }
   new_numbers[num_pizzas-1]=n;
   new_sizes[num_pizzas-1]=size;
   for(int i=0;i<m.get_num_pizzas();i++){
      if(pizza_name==m.get_menu_pizza(i).get_name()){
         new_pizzas[num_pizzas-1]=m.get_menu_pizza(i);
	 break;
      }
   }
   if(numbers){
      delete [] numbers;
   }
   if(pizzas){
      delete [] pizzas;
   }
   if(sizes){
      delete [] sizes;
   }
   numbers=new_numbers;
   sizes=new_sizes;
   pizzas=new_pizzas;
}





Restaurant::Restaurant(){
   Menu menu;
   num_employees=0;
   employees=NULL;
   week=new hours[7];
   name="";
   phone="";
   address="";
   num_orders=0;
   orders=NULL;
}

Restaurant::~Restaurant(){
   //menu.~Menu();
   if(this->employees){
      delete [] employees;
   }
   if(this->week){
      delete [] week;
   }
   if(this->orders){
      delete [] orders;
   }
}

Restaurant::Restaurant(const Restaurant &old_restaurant){
   num_employees=old_restaurant.num_employees;
   employees=new employee[num_employees];
   for(int i=0;i<num_employees;i++){
      employees[i]=old_restaurant.employees[i];
   }
   week=new hours[7];
   for(int i=0;i<7;i++){
      week[i]=old_restaurant.week[i];
   }
   name=old_restaurant.name;
   phone=old_restaurant.phone;
   address=old_restaurant.address;
}

void Restaurant::operator=(const Restaurant &old_restaurant){
   num_employees=old_restaurant.num_employees;
   if(this->employees){
      delete [] employees;
   }
   employees=new employee[num_employees];
   for(int i=0;i<num_employees;i++){
      employees[i]=old_restaurant.employees[i];
   }
   if(this->week){
      delete [] week;
   }
   week=new hours[7];
   for(int i=0;i<7;i++){
      week[i]=old_restaurant.week[i];
   }
   name=old_restaurant.name;
   phone=old_restaurant.phone;
   address=old_restaurant.address;
}

int Restaurant::get_num_employees() const{
   return num_employees;
}

void Restaurant::add_employee(employee e){
   num_employees++;
   employee *new_employees=new employee[num_employees];
   for(int i=0;i<num_employees-1;i++){
      new_employees[i]=employees[i];
   }
   new_employees[num_employees-1]=e;
   if(employees){
      delete [] employees;
   }
   employees=new_employees;
}

employee Restaurant::get_employee(int n) const{
   if(n>=num_employees){
      cout << "Out-of-range index passed to Restaurant::get_employee!" << endl;
      exit(1);
   }
   return employees[n]; 
}

hours Restaurant::get_hours(string weekday) const{
   for(int i=0;i<7;i++){
      if(weekday==week[i].day){
         return week[i];
      }
   }
   cout << "Invalid day passed to Restaurant::get_hours!" << endl;
   hours defaulthours;
   return defaulthours;
}

void Restaurant::set_hours(hours h){
   for(int i=0;i<7;i++){
      if(h.day==week[i].day){
         week[i]=h;
      }
   }
}

string Restaurant::get_name() const{
   return name;
}

void Restaurant::set_name(string name){
   this->name=name;
}

string Restaurant::get_phone() const{
   return phone;
}

void Restaurant::set_phone(string phone){
   this->phone=phone;
}

string Restaurant::get_address() const{
   return address;
}

void Restaurant::set_address(string address){
   this->address=address;
}

Menu Restaurant::get_menu() const{
   Menu result=menu;
   return result;
}

void Restaurant::load_menu(){
   ifstream f;
   f.open("menu.txt");
   string name;
   int small_cost;
   int medium_cost;
   int large_cost;
   int num_ingredients;
   string ingredient;
   if(f.is_open()){
      while(!f.eof()){
         Pizza p;
         f >> name;
	 p.set_name(name);
	 f >> small_cost;
	 p.set_cost(0,small_cost);
	 f >> medium_cost;
	 p.set_cost(1,medium_cost);
	 f >> large_cost;
	 p.set_cost(2,large_cost);
	 f >> num_ingredients;
	 for(int i=0;i<num_ingredients;i++){
	    f >> ingredient;
	    p.add_ingredient(ingredient);
	 }
	 f.ignore(256,'\n');
	 menu.add_to_menu(p);
	 if(f.peek()==EOF){
	    break;
	 }
      }
      f.close();
   }
   else {cout << "menu.txt failed to open" << endl; exit(1);}
}

void Restaurant::load_employee(){
   if(employees){
      delete [] employees;
   }
   num_employees=0;
   int employee_blocks=1;
   employees=new employee[10];
   ifstream f;
   f.open("employee.txt");
   if(f.is_open()){
      while(f.peek()!=EOF){
         employee e;
         f >> e.id;
         f >> e.password;
         f >> e.first_name;
         f >> e.last_name;
	 num_employees++;
	 if(num_employees>employee_blocks*10){
	    employee_blocks++;
	    employee *new_employees=new employee[employee_blocks*10];
	    for(int i=0;i<(employee_blocks-1)*10;i++){
	       new_employees[i]=employees[i];
	    }
	    delete [] employees;
	    employees=new_employees;
	 }
	 employees[num_employees-1]=e;
      }
      f.close();
   }
   else {cout << "employee.txt failed to open" << endl; exit(1);}
}

void Restaurant::load_restaurant_info(){
   ifstream f;
   f.open("restaurant_info.txt");
   if(f.is_open()){
      getline(f,name);
      getline(f,phone);
      getline(f,address);
      for(int i=0;i<7;i++){
         f >> week[i].day;
	 f >> week[i].open_hour;
	 f >> week[i].close_hour;
      }
      f.close();
   }
   else {cout << "restaurant_info.txt failed to open!" << endl; exit(1);}
}

int size_letter_to_number(char c){
   if(c=='S'){
      return 0;
   }
   else if(c=='M'){
      return 1;
   }
   else if(c=='L'){
      return 2;
   }
   else{
      cout << "invalid size in orders.txt: " << c << endl;
      exit(1);
   }
}

void Restaurant::load_orders(){
   if(orders){
      delete [] orders;
   }
   num_orders=0;
   orders=new Order[100];

   string pizza_name;
   char size;
   int isize;
   int quantity;

   ifstream f;
   f.open("orders.txt");
   if(f.is_open()){
      while(!(f.peek()==EOF)){
         Order added;
	 f >> added.order_num;
	 f >> added.customer_name;
	 f >> added.customer_cc;
	 f >> added.customer_phone;
	 while(!(f.peek()=='\n'||f.peek()==EOF)){
	    f >> pizza_name;
	    f >> size;
	    isize=size_letter_to_number(size);
            f >> quantity;
	    added.add_to_order(quantity,isize,pizza_name,menu);
	 }
         orders[num_orders]=added;
	 num_orders++;
	 f.ignore(256,'\n');
      }
      f.close();
   }
   else{cout << "orders.txt could not open!" << endl;exit(1);}
}

void Restaurant::load_data(){
   load_menu();
   load_employee();
   load_restaurant_info();
   load_orders();
}

string remove_spaces(string s){
   for(int i=0;i<(int)(s.length());i++){
      if(s.at(i)==' '){
         s[i]='_';
      }
   }
   return s;
}

void Restaurant::write_menu() const{
   remove("menu.txt");
   ofstream f;
   f.open("menu.txt");

   Pizza writing;
   if(f.is_open()){
      for(int i=0;i<menu.get_num_pizzas();i++){
         writing=menu.get_menu_pizza(i);
	 f << remove_spaces(writing.get_name()) << " ";
	 f << writing.get_cost(0) << " ";
	 f << writing.get_cost(1) << " ";
	 f << writing.get_cost(2) << " ";
	 f << writing.get_num_ingredients() << " ";
	 for(int j=0;j<writing.get_num_ingredients()-1;j++){
	    f << remove_spaces(writing.get_ingredient(j)) << " ";
	 }
	 f << remove_spaces(writing.get_ingredient(writing.get_num_ingredients()-1)) << endl;
      }
      f.close();
   }
   else{cout << "menu.txt could not open!" << endl;exit(1);}
}

void Restaurant::write_restaurant_info() const{
   remove("restaurant_info.txt");
   ofstream f;
   f.open("restaurant_info.txt");

   if(f.is_open()){
      f << name << endl;
      f << phone << endl;
      f << address << endl;
      for(int i=0;i<7;i++){
         f << week[i].day << " ";
	 f << remove_spaces(week[i].open_hour) << " ";
	 f << remove_spaces(week[i].close_hour) << endl;
      }
      f.close();
   }
   else{cout << "restaurant_info.txt could not open!" << endl;exit(1);}
}

string size_number_to_letter(int n){
   if(n==0) return "S";
   else if(n==1) return "M";
   else if(n==2) return "L";
   else{
      cout << "Invalid size passed to size_number_to_letter!" << endl;
      return "?";
   }
}

void Restaurant::write_orders() const{
   remove("orders.txt");
   ofstream f;
   f.open("orders.txt");

   if(f.is_open()){
      for(int i=0;i<num_orders;i++){
         f << orders[i].order_num << " ";
	 f << remove_spaces(orders[i].customer_name) << " ";
	 f << orders[i].customer_cc << " ";
	 f << orders[i].customer_phone;
	 for(int j=0;j<orders[i].num_pizzas;j++){
	    f << " " << remove_spaces(orders[i].pizzas[j].get_name());
	    f << " " << size_number_to_letter(orders[i].sizes[j]);
	    f << " " << orders[i].numbers[j];
	 }
	 f << endl;
      }
      f.close();
   }
   else{cout << "orders.txt could not open!" << endl;exit(1);}
}

void Restaurant::write_data() const{
   write_menu();
   write_restaurant_info();
   write_orders();
}

//used int for ID, will convert it to int upon input, not here.
bool Restaurant::login(int id, string password) const{
   for(int i=0;i<num_employees;i++){
      if(employees[i].id==id&&employees[i].password==password){
	 cout << "Welcome " << employees[i].first_name << " " << employees[i].last_name << "!" << endl;
         return true;
      }
   }
   return false;
}

void Restaurant::view_menu() const{
   cout << name << ": Menu:" << endl;
   menu.display_menu();
}

void Restaurant::view_hours() const{
   cout << name << ": Hours:" << endl;
   for(int i=0;i<7;i++){
      cout << week[i].day << ": Opens " << week[i].open_hour << ", Closes " << week[i].close_hour << "." << endl;
   }
}

void Restaurant::view_address() const{
   cout << name << ": Address: " << address << endl;
}

void Restaurant::view_phone() const{
   cout << name << ": Phone number: " << phone << endl;
}

void Restaurant::search_menu_by_price(){
   int upper_bound=get_positive_int("How much is your budget?","Not a positive integer.");
   Menu search_menu=menu.search_pizza_by_cost(upper_bound);
   search_menu.display_menu();
   bool order_off=yes_no("Would you like to order off this search(Yes/no)?","Please answer Yes or No.");
   if(order_off){
      Order o=create_order(search_menu);
      place_order(o);
   }
}

void Restaurant::search_by_ingredients(){
   bool quit=false;
   string *include=new string[10];
   int num_include=0;
   string *exclude=new string[10];
   int num_exclude=0;
   quit=!yes_no("Would you like to refine your search by including ingredients?","Please answer 'Yes' or 'No'.");
   while(!quit&&num_include<10){
      cout << "What ingredient do you want to include?" << endl;
      cin >> include[num_include];
      num_include++;
      if(num_include<10){
         quit=!yes_no("Would you like to include another ingredient?","Please answer 'Yes' or 'No'.");
      }
   }
   quit=!yes_no("Would you like to refine your search by excluding ingredients?","Please answer 'Yes' or 'No'.");
   while(!quit&&num_exclude<10){
      cout << "What ingredient do you want to exclude?" << endl;
      cin >> exclude[num_exclude];
      num_exclude++;
      if(num_exclude<10){
         quit=!yes_no("Would you like to include another ingredient?","Please answer 'Yes' or 'No'.");
      }
   }
   Menu m1=menu.search_pizza_by_ingredients_to_include(include,num_include);
   Menu m2=m1.search_pizza_by_ingredients_to_exclude(exclude,num_exclude);
   m2.display_menu();
   bool order_off=yes_no("Would you like to order off this search(Yes/No)?","Please answer Yes or No.");
   if(order_off){
      Order o=create_order(m2);
      place_order(o);
   }
}

int get_size_input(){
   string size;
   cout << "What size do you want?" << endl;
   while(1){
      getline(cin,size);
      if(case_insens_compare(size,"small")){
         return 0;
      }
      else if(case_insens_compare(size,"medium")){
         return 1;
      }
      else if(case_insens_compare(size,"large")){
         return 2;
      }
      else{
         cout << "Please enter 'Small','Medium', or 'Large'." << endl;
      }
   }
}

Order Restaurant::create_order(const Menu &m){
   bool quit=false;
   int option=0;
   int size;
   int quantity;
   Pizza adding;
   Order result;
   while(!quit){
      cout << "Which pizza would you like to add to order?" << endl;
      m.display_menu();
      option=0;
      while(!(option>=1&&option<=m.get_num_pizzas())){
         option=get_positive_int("Which pizza would you like to order?","That's not an option.");
	 if(!(option>=1&&option<=m.get_num_pizzas())){
	    cout << "That's not an option." << endl;
	 }
      }
      adding=m.get_menu_pizza(option-1);
      size=get_size_input();
      while(m.get_menu_pizza(option-1).get_cost(size)==0){
         cout << "Not available on this menu." << endl;
	 size=get_size_input();
      }
      quantity=get_positive_int("How many do you want?","That's not a positive int.");
      result.add_to_order(quantity,size,adding.get_name(),m);
      quit=!yes_no("Would you like to add more to the order?","Please answer 'Yes' or 'No'.");
   }
   return result;
}

void Restaurant::place_order(Order o){
   string customer_name;
   cout << "Please enter your name: " << endl;
   getline(cin,customer_name);
   o.customer_name=customer_name;
   o.customer_phone=get_positive_long("Please enter your phone number(as an integer.)","That's not a valid number.");
   if(yes_no("Are you sure you want to order?","Please answer 'Yes' or 'No'.")){
      o.customer_cc=get_positive_long("Please enter your credit card#.","That's not a valid number.");
   }
   else return;
   if(num_orders<100){
      o.order_num=num_orders+1;
      orders[num_orders]=o;
      num_orders++;
   }
   else{
      cout << "Could not place order: too many orders!(Max 100)" << endl;
   }
}

void Restaurant::change_hours(){
   bool quit=false;
   string day;
   string time;
   while(!quit){
      cout << "What day do you want to change hours for?" << endl;
      getline(cin,day);
      for(int i=0;i<7;i++){
         if(case_insens_compare(week[i].day,day)){
	    cout << "What time does the store open on " << week[i].day << "?" << endl;
	    getline(cin,time);
	    week[i].open_hour=time;
	    cout << "What time does the store close on " << week[i].day << "?" << endl;
	    getline(cin,time);
	    week[i].close_hour=time;
	    quit=!yes_no("Would you like to change another day?","Please answer 'Yes' or 'No'.");
	 }
      }
   }
}

void Restaurant::add_to_menu(){
   Pizza added;
   string name;
   string ingredient;
   cout << "What is the pizza's name?" << endl;
   cin >> name;
   added.set_name(name);
   int cost=get_positive_int("What is the small cost(0 for N/A).","That's not an integer.");
   added.set_cost(0,cost);
   cost=get_positive_int("What is the medium cost(0 for N/A).","That's not an integer.");
   added.set_cost(1,cost);
   cost=get_positive_int("What is the large cost(0 for N/A).","That's not an integer.");
   added.set_cost(2,cost);
   bool quit=false;
   while(!quit){
      cout << "What is ingredient " << added.get_num_ingredients()+1 << "?" << endl;
      cin >> ingredient;
      added.add_ingredient(ingredient);
      quit=!yes_no("Do you want to add another ingredient(Yes/No)?","Please say Yes or No.");
   }
   menu.add_to_menu(added);
}

void Restaurant::remove_from_menu(){
   menu.display_menu();
   int choice=0;
   while(!(choice>=1&&choice<=menu.get_num_pizzas())){
      choice=get_positive_int("Which pizza do you want to remove(use number)?","That's not an option.");
      if(!(choice>=1&&choice<=menu.get_num_pizzas())){
         cout << "That's not an option." << endl;
      }
   }
   menu.remove_from_menu(choice-1);
}

void Restaurant::view_orders() const{
   int size;
   for(int i=0;i<num_orders;i++){
      cout << orders[i].order_num << " ";
      cout << orders[i].customer_name << " ";
      cout << orders[i].customer_cc << " ";
      cout << orders[i].customer_phone << " ";
      for(int j=0;j<orders[i].num_pizzas;j++){
         cout << orders[i].pizzas[j].get_name() << " ";
	 size=orders[i].sizes[j];
	 if(size==0) cout << "S ";
	 else if(size==1) cout << "M ";
	 else if(size==2) cout << "L ";
	 else cout << "? ";
	 cout << orders[i].numbers[j];
	 if(j!=orders[i].num_pizzas-1) cout << " ";
      }
      cout << endl;
   }
}

void Restaurant::remove_orders(){
   view_orders();
   int choice=0;
   while(!(choice>=1&&choice<=num_orders)){
      choice=get_positive_int("Which order do you want to remove?","That's not an option.");
      if(!(choice>=1&&choice<=num_orders)){
         cout << "That's not an option." << endl;
      }
   }

   for(int i=choice-1;i<num_orders-1;i++){
      orders[i]=orders[i+1];
      orders[i].order_num-=1;
   }
   num_orders--;
   Order defaultorder;
   orders[num_orders]=defaultorder;
}

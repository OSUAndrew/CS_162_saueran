#ifndef PIZZA_CLASSES
#define PIZZA_CLASSES

#include<iostream>
#include<string>

using namespace std;

struct employee{
   int id;
   string password;
   string first_name;
   string last_name;
};

struct hours{
   string day;
   string open_hour;
   string close_hour;
};

class Pizza{
   private:
      string name;
      int small_cost;
      int medium_cost;
      int large_cost;
      int num_ingredients;
      string *ingredients;
   public:
      Pizza();
      ~Pizza();
      Pizza(const Pizza &);
      void operator=(const Pizza &);
      string get_name() const;
      void set_name(string);
      int get_cost(int) const;
      void set_cost(int size,int cost);
      int get_num_ingredients() const;
      string get_ingredient(int) const;
      void display_ingredients() const;
      void add_ingredient(string);
      void subtract_ingredient(int);
};

class Menu{
   private:
      int num_pizzas;
      Pizza *pizzas;
   public:
      Menu();
      ~Menu();
      Menu(const Menu &);
      void operator=(const Menu &);
      
      int get_num_pizzas() const;
      Pizza get_menu_pizza(int) const;
      void display_menu() const;

      void add_to_menu(Pizza);
      void remove_from_menu(int);

      Menu search_pizza_by_cost(int upper_bound);
      Menu search_pizza_by_ingredients_to_include(string *, int);
      Menu search_pizza_by_ingredients_to_exclude(string *, int);

};

class Order{
   public:
      int order_num;
      string customer_name;
      long customer_cc;
      long customer_phone;

      int num_pizzas;
      int *numbers;
      int *sizes;
      Pizza *pizzas;

      Order();
      ~Order();
      Order(const Order &);
      void operator=(const Order &);
      void add_to_order(int n,int size,string pizza_name,const Menu &m);
};

class Restaurant{
   private:
      Menu menu;
      int num_employees;
      employee *employees;
      hours *week;
      string name;
      string phone;
      string address;
      int num_orders;
      Order *orders;
   public:
      //constructor and big three
      Restaurant();
      ~Restaurant();
      Restaurant(const Restaurant &);
      void operator=(const Restaurant &);
      //getters and setters
      int get_num_employees() const;
      void add_employee(employee);
      employee get_employee(int) const;
      hours get_hours(string) const;
      void set_hours(hours);
      string get_name() const;
      void set_name(string);
      string get_phone() const;
      void set_phone(string);
      string get_address() const;
      void set_address(string);
      Menu get_menu() const;
      //file input
      void load_menu();
      void load_employee();
      void load_restaurant_info();
      void load_orders();
      void load_data();
      //file output
      void write_menu() const;
      void write_restaurant_info() const;
      void write_orders() const;
      void write_data() const;
      //functionality
      bool login(int id, string password) const;
      void view_menu() const;
      void view_hours() const;
      void view_address() const;
      void view_phone() const;
      void search_menu_by_price();
      void search_by_ingredients();
      Order create_order(const Menu &);
      void place_order(Order);
      void change_hours();
      void add_to_menu();
      void remove_from_menu();
      void view_orders() const;
      void remove_orders(); 
};
#endif
